<?php 
// affiche un input avec les caractéristiques de bootstrap
function input($type, $titre, $id, $name, $placeholder, $required, $value, $autre){
    $required = $required ? "required" : "";
    ?>
        <div class="form-group">
            <label for="<?php echo $id; ?>"><?php echo $titre; ?></label>
            <input type="<?php echo $type; ?>" value="<?php echo $value; ?>" <?php echo $autre; ?> class="form-control" id="<?php echo $id; ?>" <?php echo $required; ?> name="<?php echo $name; ?>" placeholder="<?php echo $placeholder; ?>">
        </div>
    <?php
}

// ouvrir une session
function ouvrir_session(){
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    }
}

//Pagination
function pagination($nombreDePages, $pageActuelle, $url, $ancre){
    echo '<p align="center">Page(s) : '; //Pour l'affichage, on centre la liste des pages
    for($i=1; $i<=$nombreDePages; $i++) //On fait notre boucle
    {
         //On va faire notre condition
         if($i==$pageActuelle) //Si il s'agit de la page actuelle...
         {
             echo ' [ '.$i.' ] ';
         }	
         else //Sinon...
         {
              echo '<a href="'.$url.'&numero-page='.$i.''.$ancre.'">'.$i.'</a> ';
         }
    }
    echo '</p>';
}


// affiche la publicité
function afficher_publicite(){
    ?>

    <?php
}
    
// affiche l'introduction
function afficher_introduction(){
        $langue = langue();
        if($langue=="fr"){
            ?>
                <p>www.journalperso.fr est une <strong>communauté d’internautes en ligne</strong> qui s’exprime sur leurs journaux d’absolument tout ceux qu’ils veulent.</p>
                <p>Le site permet de créer des <strong>journaux personnels en ligne</strong> que l’ont peut mettre gratuit ou payant ainsi gagner de l'argent grace à notre solution de paiement pour chaque accès payant.</p>
                <p>Vous pouvez créer plusieurs journaux personnels et dans ces journaux vous pouvez y noter tout ce que vous vous voulez (texte, images, vidéos, fichiers) et du contenu interessant.</p>
                <p>Vous pouvez en faire un journal intime en ligne ou une page de connaissances avec toutes vos connaissances dans un domaine précis et partagez-le !</p>
                <p>Ecrivez un ou plusieurs journaux intimes en ligne ou ecrivez un livre en ligne.</p>
                <p>Vous disposez d'un espace de création de journaux personnel très puissant et chaque journal dispose de sa page en ligne.</p>
                <p>Pour une utilisation optimale sur ordinateurs, smartphones et tablettes ajouter le site <span class="violet">à vos favoris</span>.</p>
                <p>Nous avons développé un <strong>système de rédaction de contenu unique</strong> en son genre nommé MemoPlay.</p>
                <p>Plus vous avez de visiteurs sur votre journal plus il sera bien classé et populaire et plus vous avez de chance de gagner de l'argent.</p>
                <p>Si le site a du succès il sera nettement amélioré. Vos données restent confidentielles et ne seront pas donné à un tiers. Le site est entièrement sécurisé.</p>
                <p>En écrivant un journal il sera présent sur le site et sur Google.</p>
                <p>Vous pouvez gagner beaucoup d'argent sur internet avec votre ou vos journaux.</p>
                <ul>
                    <li>Paiement dès 1€.</li>
                    <li>Vous gagnez 30% des gains de vos filleuls de niveau 1 et 10% des gains de vos filleuls de niveau 2.</li>
                    <li>90% des gains sont reversés aux membres.</li>
                </ul>
            <?php
        }elseif($langue=="en"){
            ?>
            <div style="padding:2px;">   
                <p>www.journalperso.com is an <strong>community of online users</strong> who speaks on their journals about absolutely anyone they want.</p>
                <p>The site allows you to create <strong> personal diaries online </strong> that you can put free or paid and earn money through our payment solution for each paying access.</p>
                <p>You can create several personal diaries and in these diaries you can write down everything you want (text, images, videos, files) and interesting content.</p>
                <p>You can make a diary online or a page of knowledge with all your knowledge in a specific area and share it!</p>
                <p>You have a very powerful personal journal space, and each journal has its own online page.</p>
                <p>Write one or more diaries online or write a book online.</p>
                <p>For optimal use on computers, smartphones and tablets add <span class="violet"> to your favorites </span>.</p>
                <p>We've developed a <strong> unique content writing system </strong> of its kind called MemoPlay. </p>
                <p>The more visitors you have on your newspaper, the better ranked and popular it is, the more likely you are to make money.</p>
                <p>If the site is successful it will be significantly improved. Your data will remain confidential and will not be given to a third party. The site is fully secure.</p>
                <p>By writing a newspaper he will be present on the site and on Google.</p>
                <p>You can make a lot of money on the internet with your newspaper (s).</p>
                <ul>
                    <li> Payment from 1 €.</li>
                    <li> You earn 30% of the earnings of your level 1 referrals and 10% of your level 2 referrals. </li>
                    <li> 90% of the winnings go to members.</li>
                </ul>
            </div>
            <?php
        }
        ?>
    <?php
}
    
// affiche les meilleurs journaux
function afficher_meilleurs_journaux($nbr, $page){
        $langue = langue();
        ?>
            <div id="journaux-connus-responsives">
                <?php 
                // affiche les 30 premiers journaux connus
                afficher_journaux_connus($nbr, $page); 
                ?>
            </div>
            <center>
            <form action="index.php?page=recherche" method="post">
                <div class="input-group mb-3">
                    <input type="text" name="recherche" class="form-control" minlength='1' maxlength='50' placeholder="<?php if($langue=="fr"){echo "Rechercher un journal...";}elseif($langue=="en"){echo"Search a journal...";} ?>" aria-label="<?php if($langue=="fr"){echo "Rechercher un journal";}elseif($langue=="en"){echo"Search a journal";} ?>" aria-describedby="button-addon2">
                    <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="submit" id="button-addon2"><?php if($langue=="fr"){echo "Rechercher";}elseif($langue=="en"){echo"Search";} ?></button>
                    </div>
                </div>
            </form>
            </center>
    <?php
}
    
// affiche les meilleurs journaux en carte
function afficher_meilleurs_journaux_card(){
        $langue = langue();
        // recherche dans les journaux les 4 les plus connus
        $requete = "SELECT id, nom, description FROM `journaux` ORDER BY vues DESC LIMIT 16";
        $reponse = select_bdd($requete);
        while ($rep = $reponse->fetch()){
                $nom = $rep["nom"];
                $description = $rep["description"];
                $id = $rep["id"];
                // affiche la carte pour le journal plus connus avec ses infos
                ?>
                <li>
                    <div style="height:200px;width:250px;display:block" class="card text-center card-journaux-connus">
                    <div class="card-body">
                        <div style="height:100px;overflow-y: scroll;">
                            <h5 class="card-title"><strong><?php echo $nom; ?></strong></h5>
                            <p class="card-text"><?php echo $description; ?></p>
                        </div>
                        <p><span class="nbr_vues_journal_card"><?php echo affichervuejournal($id); ?></span> <?php if($langue=="fr"){echo "vues";}elseif($langue=="en"){echo"views";} ?></p>
                        <a target="_blank" class="btn btn-primary btn-sm" href="http://www.journalperso.fr/journal<?php echo $id;?>"><?php if($langue=="fr"){echo "Visiter";}elseif($langue=="en"){echo"Visit";} ?></a>
                    </div>
                    </div>
                </li>
            <?php 
        }
        ?>
<?php
}
    
//affiche le head html
function afficher_head($title, $description){
        $langue = langue();
    ?>
            <!-- Affiche les metas pour les recherches -->
            <meta name="Content-Type" content="UTF-8">
            <meta name="Content-Language" content="<?php echo $langue; ?>">
            <meta name="Description" content="<?php echo $description; ?>">
            <META name="keywords" content="Journalisme, journal personnel en ligne, journaux en ligne, gagner argent, jeux en ligne, web rédacteur, journal intime">
            <meta name="Subject" content="Journalisme">
            <meta name="Copyright" content="Journalperso.fr">
            <meta name="Author" content="Ange-José Michelin">
            <meta name="Publisher" content="Ange-José Michelin">
            <meta name="Identifier-Url" content="https://www.journalperso.fr">
            <meta name="Reply-To" content="webmaster@journalperso.fr">
            <meta name="Revisit-After" content="1 day">
            <meta name="Robots" content="all">
            <meta name="Rating" content="general">
            <meta name="Distribution" content="global">
            <meta name="Geography" content="france">
            <meta name="Category" content="literature">
            <meta name="DC.Content-Type" content="UTF-8">
            <meta name="DC.Content-Language" content="fr">
            <meta name="DC.Description" content="<?php echo $description; ?>">
            <meta name="DC.Subject" content="Journalisme">
            <meta name="DC.Copyright" content="Journalperso.fr">
            <meta name="DC.Author" content="Ange-José Michelin">
            <meta name="DC.Publisher" content="Ange-José Michelin">
            <meta name="DC.Identifier-Url" content="https://www.journalperso.fr">
            <meta name="DC.Reply-To" content="webmaster@journalperso.fr">
            <meta name="DC.Revisit-After" content="1 day">
            <meta name="DC.Robots" content="all">
            <meta name="DC.Rating" content="general">
            <meta name="DC.Distribution" content="global">
            <meta name="DC.Geography" content="france">
            <meta name="DC.Category" content="literature">
            
            <!-- Liens vers elements et fichiers utiles -->
            <link rel="stylesheet" href="ressources/bootstrap/css/bootstrap.min.css"/>
            <link rel="stylesheet" href="ressources/css/styles-min.css"/>
            <link rel="stylesheet" href="ressources/jquery-ui/jquery-ui.min.css"/>    
            <link rel="stylesheet" href="ressources/jquery-ui/jquery-ui.theme.min.css"/>
            <link rel="stylesheet" type="text/css" href="ressources/cleditor/jquery.cleditor.css"/>
            <script type="text/javascript" src="ressources/jquery/jquery.js"></script>
            <script type="text/javascript" src="ressources/cleditor/jquery.cleditor.min.js"></script>
            <script type="text/javascript" src="ressources/js/script.js"></script>
            <script type="text/javascript" src="ressources/jquery-ui/jquery-ui.min.js"></script>
            <script type="text/javascript" src="ressources/js/jquery.validate.min.js"></script>
            <!-- <link rel="stylesheet" type="text/css" href="ressources/ticketagratter/demo/demo.css" /> -->
            <script src="ressources/bootstrap/js/bootstrap.bundle.min.js"></script>
            <script src="ressources/slick/slick.min.js" type="text/javascript" charset="utf-8"></script>
            <script src='https://www.google.com/recaptcha/api.js'></script>
            <script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v3.3&appId=392499051612451&autoLogAppEvents=1"></script>
            <!--<link rel="icon" href="src/img/favicon.ico" /> -->
    
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <meta name="msapplication-TileColor" content="#ffffff">
            <meta name="msapplication-TileImage" content="ressources/favicon/ms-icon-144x144.png">
            <meta name="theme-color" content="#ffffff">  
            <meta name="viewport" content="width=device-width" />
            
            <!-- Favicon -->
            <link rel="apple-touch-icon" sizes="57x57" href="ressources/favicon/apple-icon-57x57.png">
            <link rel="apple-touch-icon" sizes="60x60" href="ressources/favicon/apple-icon-60x60.png">
            <link rel="apple-touch-icon" sizes="72x72" href="ressources/favicon/apple-icon-72x72.png">
            <link rel="apple-touch-icon" sizes="76x76" href="ressources/favicon/apple-icon-76x76.png">
            <link rel="apple-touch-icon" sizes="114x114" href="ressources/favicon/apple-icon-114x114.png">
            <link rel="apple-touch-icon" sizes="120x120" href="ressources/favicon/apple-icon-120x120.png">
            <link rel="apple-touch-icon" sizes="144x144" href="ressources/favicon/apple-icon-144x144.png">
            <link rel="apple-touch-icon" sizes="152x152" href="ressourcesc/favicon/apple-icon-152x152.png">
            <link rel="apple-touch-icon" sizes="180x180" href="ressources/favicon/apple-icon-180x180.png">
            <link rel="icon" type="image/png" sizes="192x192"  href="ressources/favicon/android-icon-192x192.png">
            <link rel="icon" type="image/png" sizes="32x32" href="ressources/favicon/favicon-32x32.png">
            <link rel="icon" type="image/png" sizes="96x96" href="ressources/favicon/favicon-96x96.png">
            <link rel="icon" type="image/png" sizes="16x16" href="ressources/favicon/favicon-16x16.png">
            <link rel="manifest" href="ressources/favicon/manifest.json">
    
            <script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v3.3&appId=756114578256555&autoLogAppEvents=1"></script>
            <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-124340528-1"></script>
            <script>
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', 'UA-124340528-1');
            </script>

            <div id="fb-root"></div>
            <script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v7.0&appId=756114578256555&autoLogAppEvents=1" nonce="AfmkE7mt"></script>

            <title><?php echo $title; ?></title>
<?php
}
    
//affiche le head html
function afficher_footer(){
        $langue = langue();
        ?>
            <!-- Affiche les infos relatives au site et aux contacts -->
            <p class="fontsize09"><span data-toggle="tooltip" data-placement="top" title="Marque deposée à l'INPI">® Journalperso.fr</span> 2018-<?php echo date('Y');?> | webmaster@journalperso.fr | <a href="index.php?page=reglement2"><?php if($langue=="fr"){echo "Règlement";}elseif($langue=="en"){echo"Regulations";} ?></a> | <a href="index.php?page=mentions-legales"><?php if($langue=="fr"){echo "Mentions Légales";}elseif($langue=="en"){echo"Legal Notice";} ?></a></p>
            <div class="fb-like" data-href="https://www.facebook.com/Journalpersofr-113698867066140/" data-width="" data-layout="box_count" data-action="like" data-size="small" data-share="true"></div>
            <script type="text/javascript" src="ressources/js/affiher_masquer_mdp.js"></script>
            <script type="text/javascript" src="ressources/js/langue.js"></script>
        <?php
}
    
// affiche le modal texte
function modal($texte){
        $langue = langue();
        ?>
        <div class="modal" id="modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php if($langue=="fr"){echo "Informations";}elseif($langue=="en"){echo"Informations";} ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p><?php echo $texte; ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php if($langue=="fr"){echo "Fermer";}elseif($langue=="en"){echo"Close";} ?></button>
            </div>
            </div>
        </div>
        </div>
        <script>
            $("#modal").modal("show")
        </script>
    <?php
}
?>
<?php

// gestion des pages
function gerer_les_pages($connecte, $page){
    if($connecte == false){
        switch ($page) {
            case "accueil":
                include('page-non-connecte/accueil.php');
                break;
            case "avis":
                include('page-non-connecte/avis.php');
                break;
            case "mentions-legales":
                include('page-non-connecte/mentionslegales.php');
                break;
            case "validation-connexion-fb":
                include('fbconnect.php');
                break;
            case "paiement-mdp-journal":
                include('paiement/paiement_mdp_journal.php');
                break;
            case "page-mdps":
                include('paiement/page_mdps.php');
                break;
            case "page-mdps2":
                include('paiement/page_mdps2.php');
                break;
            case "paiement":
                include('paiement/paiement.php');
                break;
            case "paiement-valider":
                include('paiement/paiement_valider.php');
                break;
            case "validation-inscription":
                include('page-non-connecte/validation-inscription.php');
                break;
            case "validation-compte":
                include('page-non-connecte/validation-compte.php');
                break;
            case "validation-connexion":
                include('page-non-connecte/validation-connexion.php');
                break;
            case "paiement":
                include('paiement/paiement.php');
                break;
            case "recherche":
                include('page-non-connecte/recherche.php');
                break;
            case "motdepasse-oublie":
                include('page-non-connecte/mdp-oublie.php');
                break;
            case "connexion":
                include('page-non-connecte/connexion.php');
                break;
            case "inscription":
                include('page-non-connecte/inscription.php');
                break;
            case "touslesjournaux":
                include('page-non-connecte/touslesjournaux.php');
                break;
            case "journaux-par-themes":
                include('page-non-connecte/journaux-par-themes.php');
                break;
            case "reglement2":
                include('page-non-connecte/reglement2.php');
                break;
            case null:
                include('page-non-connecte/accueil.php');
                break;
            default:
                include('page-non-connecte/accueil.php');
        }
    } elseif($connecte == true){
        switch ($page) {
            case "accueil-membre":
                include('page-connecte/accueil-membre.php');
                break;
            case "recharger":
                include('page-connecte/recharger.php');
            break;
            case "jeux":
                include('page-connecte/jeux.php');
            break;
            case "notifications":
                include('page-connecte/notifications.php');
                break;
            case "demande-paiement":
                include('page-connecte/demande-paiement.php');
                break;
            case "modifier-journal":
                include('page-connecte/modifier-journal.php');
                break;
            case "creerunjournal":
                include('page-connecte/creerunjournal.php');
                break;
            case "statistiques":
                include('page-connecte/statistiques.php');
                break;
            case "renvoi_mail_validation_compte":
                include('page-connecte/renvoi_mail_validation_compte.php');
                break;
            case "parrainnage":
                include('page-connecte/parrainnage.php');
                break;
            case "moncompte":
                include('page-connecte/mon_compte.php');
                break;
            case "reglement":
                include('page-connecte/reglement.php');
                break;
            case "parametre":
                include('page-connecte/parametre.php');
                break;
            case null:
                include('page-connecte/accueil-membre.php');
                break; 
            default:
                include('page-connecte/accueil-membre.php');
        }
    }
}

// gestion des description
function description_page($page){
    $langue = langue();
    switch ($page) {
        case "validation-connexion-fb":
            $retour = $langue == "en" ? "Write personal diaries online - Login with Facebook on the journalism site Journalperso.fr." : "Ecrivez des journaux personnels en ligne - Connexion avec Facebook sur le site de journalisme Journalperso.fr. journal intime en ligne";
            return $retour;
            break;
        case "avis":
            $retour = $langue == "en" ? "Become web editor - Opinions and testimonials on our site of sharing thanks to newspapers (intimate or public) on line." : "Ecrivez des journaux personnels en ligne - Avis et témoignages sur notre site de partage gràce à des journaux (intime ou publiques) en ligne. journal intime en ligne";
            return $retour;
            break;
        case "jeux":
            $retour = $langue == "en" ? "Earn money online - Games are available on this page. Earn money!" : "Ecrivez des journaux personnels en ligne - Les jeux sont disponible sur cette page. Gagnez de l'argent ! journal intime en ligne";
            return $retour;
        break;
        case "recharger":
            $retour = $langue == "en" ? "Write personal diaries and earn money online - Credit your account here." : "Ecrivez des journaux personnels en ligne - Recharger votre compte en argent ici. journal intime en ligne a lire";
            return $retour;
        break;
        case "touslesjournaux":
            $retour = $langue == "en" ? "Become independant journalist and earn money online - All personal diaries. Find a personal diary online, a diary or a paid newspaper on this page." : "Ecrivez des journaux personnels en ligne - Tous les journaux personnels. Trouvez un journal personnel en ligne, un journal intime ou un journal payant sur cette page. journal intime en ligne a lire";
            return $retour;
            break;
        case "journauxpartheme":
            $retour = $langue == "en" ? "Write personal diaries online - All staff classified by topics. Many themes available do not hesitate to write your own diary (diary, journal of connnances, newspaper paynt or free)." : "Ecrivez des journaux personnels en ligne - Tous les personnels journaux classés par thèmes. Beaucoup de thèmes disponible n'hésitez pas à érire votre propre journal personel (journal intime, journal de connassances, journal paynt ou gratuit). journal intime en ligne gratuit";
            return $retour;
            break;
        case "statistiques":
            $retour = $langue == "en" ? "Write personal diaries online - Statistics of your Journalperso.fr account. Sales and views on your diaries personal, intimate, public, free or paid online through our powerful editor." : "Ecrivez des journaux personnels en ligne - Statistiques de votre compte Journalperso.fr. Les ventes et les vues sur vos journaux personnels, intimes, publiques, gratuti ou payant mise en ligne gràce à notre éditeur puissant. journal intime en ligne gratuit";
            return $retour;
            break;
        case "notifications":
            $retour = $langue == "en" ? "Write personal diaries online - Your account notifications of Journalperso.fr, a web site dedicated to the journalism." : "Ecrivez des journaux personnels en ligne - Notifications de votre compte Jounrlaperso.fr, le site dédié au journalisme.";
            return $retour;
            break;
        case "mentions-legales":
            $retour = $langue == "en" ? "Write personal diaries online - Legal mentions of the site Journalperso.fr, the site to become web editor. journal of personnel psychology ranking" : "Ecrivez des journaux personnels en ligne - Mentions legales du site Journalperso.fr, le site pour devenir web rédacteur.";
            return $retour;
            break;
        case "demande-paiement":
            $retour = $langue == "en" ? "Write personal diaries online - Your payment, minimum of 1€. Write and sell personnals journals to earn money ! Simple... journal of personnel research" : "Ecrivez des journaux personnels en ligne - Faire une demande de paiement si votre solde a atteint un minimum de 1€. Ecréviez des journaux personnels et vendez les pour gagnez de l'argent... Simple non ?";
            return $retour;
            break;
        case "accueil-membre":
            $retour = $langue == "en" ? "Write personal diaries online - Write personal diaries online - Home for users. Folow instructions and create yout first personal journal. journal of personnel assessment and decisions" : "Ecrivez des journaux personnels en ligne - Accueil des membres. Suivez les instructions et écrivez voter premier journal personnel et gagnez de l'argent!";
            return $retour;
            break;
        case "creerunjournal":
            $retour = $langue == "en" ? "Write personal diaries online - Create a journal, write et sell ! journal of personnel psychology impact factor" : "Ecrivez des journaux personnels en ligne - Créer un journal, ecrivez dessus et vendez le... Vous avez votre propre page alors au travail. journal intime en ligne pour ado";
            return $retour;
            break;
        case "renvoi_mail_validation_compte":
            $retour = $langue == "en" ? "Write personal diaries online - Returning the account validation email to validate your registration on the journalism website journalperso.fr." : "Ecrivez des journaux personnels en ligne - Renvoi du mail de validation du compte pour valider votre inscription sur le site de journalisme journalperso.fr. journal intime en ligne pour fille";
            return $retour;
            break;
        case "accueil":
            $retour = $langue == "en" ? "Write personal diaries online - Access your space and create your personal journal to record your thoughts, your notes or others and share it, make the best views, make a diary or public." : "Ecrivez des journaux personnels en ligne - Accédez à votre espace et créez votre journal personnel pour y noter vos pensées, vos notes ou autres et partagez-le, faites les meilleures vues, faites en un journal intime ou publique. journal personnel numérique";
            return $retour;
            break;
        case "parrainnage":
            $retour = $langue == "en" ? "Write personal diaries online - Page of sponsorshipt for you account. Earn more!!!" : "Ecrivez des journaux personnels en ligne - Page de parrainnage pour votre compte. Gagnez beacoups plsu grace à vos filleuls qui écriveront des journaux personnels à leur tour et auront d'autres filleuls à leur tour/";
            return $retour;
            break;
        case "reglement":
            $retour = $langue == "en" ? "Write personal diaries online - Page of regulations of journalperso.fr, the website dedicated to journalism." : "Ecrivez des journaux personnels en ligne - Page du reglement du site journalperso.fr, site de journalisme independant.";
            return $retour;
            break;
        case "parametre":
            $retour = $langue == "en" ? "Write personal diaries online - Page of settings of your account." : "Ecrivez des journaux personnels en ligne - Page des parametres de votre compte.";
            return $retour;
            break;
        case "validation-inscription":
            $retour = $langue == "en" ? "Write personal diaries online - Validate your registration at journalperso.fr.  Write more to earn more !" : "Ecrivez des journaux personnels en ligne - Valider votre inscription à journalperso.fr. Ecrivez plus pour gagnez plus!";
            return $retour;
            break;
        case "validation-connexion":
            $retour = $langue == "en" ? "Write personal diaries online - Confirm your connection to journalperso.fr.  Write more to earn more !" : "Ecrivez des journaux personnels en ligne - Valider votre connexion à journalperso.fr. Ecrivez plus pour gagnez plus!";
            return $retour;
            break;
        case "paiement":
            $retour = $langue == "en" ? "Write personal diaries online - Make your payment online to activate your account." : "Ecrivez des journaux personnels en ligne - Effectuez votre paiement en ligne pour activé votre compte.";
            return $retour;
            break;
        case "paiement_valider":
            $retour = $langue == "en" ? "Write personal diaries online - Validate your payment." : "Ecrivez des journaux personnels en ligne - Validez votre paiement.";
            return $retour;
            break;
        case "paiement-mdp-journal":
            $retour = $langue == "en" ? "Write personal diaries online - Make your payment online to get code for the personnal journal." : "Ecrivez des journaux personnels en ligne - Effectuez votre paiement en ligne pour obtenir le code du journal personnel.";
            return $retour;
            break;
        case "page-mdps":
            $retour = $langue == "en" ? "Write personal diaries online - Validate your payment for the personnal journal." : "Ecrivez des journaux personnels en ligne - Validez votre paiement pour le journal personnel.";
            return $retour;
            break;
        case "page-mdps2":
            $retour = $langue == "en" ? "Write personal diaries online - Get password of yout account journalperso.fr." : "Ecrivez des journaux personnels en ligne - Obtenir le mot de passe de votre compte Journalperso.fr.";
            return $retour;
            break;
        case "recherche":
            $retour = $langue == "en" ? "Write personal diaries online - Do a search on the entire site users for personnals journals of journalperso.fr." : "Ecrivez des journaux personnels en ligne - Effectuez une recherche sur l'ensemble des utilisateus du site sur les journaux personnels de journalperso.fr.";
            return $retour;
            break;
        case "reglement2":
            $retour = $langue == "en" ? "Write personal diaries online - Page of regulations of personnals journals website www.journalperso.fr." : "Ecrivez des journaux personnels en ligne - Page du reglement du site de journaux personnnels journalperso.fr.";
            return $retour;
            break;
        case "inscription":
            $retour = $langue == "en" ? "Write personal diaries online - Register on the site of journalism and web editors journalperso.fr." : "Ecrivez des journaux personnels en ligne - S'inscrire sur le site de jounralisme et de rédaction web Journalperso.fr.";
            return $retour;
            break;
        case "connexion":
            $retour = $langue == "en" ? "Write personal diaries online - Login to the site of journalism and web editors journalperso.fr." : "Ecrivez des journaux personnels en ligne - Se connecter sur le site de journalisme et de rédaction web journalperso.fr.";
            return $retour;
            break;
        case "motdepasse-oublie":
            return "";
            $retour = $langue == "en" ? "Write personal diaries online - Come to this page if you have forgotten your password of the journalism site; Journalperso.fr" : "Ecrivez des journaux personnels en ligne - Venez sur cette page si vous avez oublié votre mot de passe sur le site de journalisme journalperso.fr.";
            return $retour;
            break;
        case "modifier-journal":
            $retour = $langue == "en" ? "Write personal diaries online - Access your space and create your personal journal to record your thoughts, your notes or others and share it, make the best views, make a diary or public." : "Ecrivez des journaux personnels en ligne - Accédez à votre espace et créez votre journal personnel pour y noter vos pensées, vos notes ou autres et partagez-le, faites les meilleures vues, faites en un journal intime ou publique.";
            return $retour;
            break;   
        case null:
            $retour = $langue == "en" ? "Write personal diaries online - Access your space and create your personal journal to record your thoughts, your notes or others and share it, make the best views, make a diary or public." : "Ecrivez des journaux personnels en ligne - Accédez à votre espace et créez votre journal personnel pour y noter vos pensées, vos notes ou autres et partagez-le, faites les meilleures vues, faites en un journal intime ou publique.";
            return $retour;
            break;
        default:
            $retour = $langue == "en" ? "Write personal diaries online - Access your space and create your personal journal to record your thoughts, your notes or others and share it, make the best views, make a diary or public." : "Ecrivez des journaux personnels en ligne - Accédez à votre espace et créez votre journal personnel pour y noter vos pensées, vos notes ou autres et partagez-le, faites les meilleures vues, faites en un journal intime ou publique.";
            return $retour;
    }
}


// gestion des titres
function titre_page($page){
    $langue = langue();
        switch ($page) {
            case "touslesjournaux":
                $retour = $langue == "en" ? "Journalperso.fr - All newspapers - Write personal journals and become a web editor!" : "Journalperso.fr - Tous les journaux - Ecrivez des journaux persoonnels et devenez web rédacteur !";
                return $retour;
            break;
            case "recharger":
                $retour = $langue == "en" ? "Journalperso.fr - Credit - Site dédié au journalisme independant... Vous pouvez aussi écrire des journaux intimes!" : "Journalperso.fr - Recharger - Site dédié au journalisme independant... Vous pouvez aussi écrire des journaux intimes!";
                return $retour;
            break;
            case "jeux":
                $retour = $langue == "en" ? "Journalperso.fr - Games - Devenez web rédacteur sur Journalperso.fr et gagnez de l'argent!" : "Journalperso.fr - Jeux - Devenez web rédacteur sur Journalperso.fr et gagnez de l'argent!";
                return $retour;
            break;
            case "avis":
                $retour = $langue == "en" ? "Journalperso.fr - Opinions and testimonials - Ecrivez des journaux interressant et gagner de l'argent sur Journalperso.fr!" : "Journalperso.fr - Avis et témoignages - Ecrivez des journaux interressant et gagner de l'argent sur Journalperso.fr!";
                return $retour;
            break;
            case "journauxpartheme":
                $retour = $langue == "en" ? "Journalperso.fr - Themes journals - Become web editor! Website dedicated to independent journalism..." : "Journalperso.fr - Journaux par themes - Devenez web rédacteur ! Site dédié au journalisme independant...";
                return $retour;
                break;
            case "validation-connexion-fb":
                $retour = $langue == "en" ? "Journalperso.fr - Facebook Connexion - Ecrivez des articles faites les connaitres et gagnez de l'argent!" : "Journalperso.fr - Connexion avec Facebook - Ecrivez des articles faites les connaitres et gagnez de l'argent!";
                return $retour;
                break;
            case "renvoi_mail_validation_compte":
                $retour = $langue == "en" ? "Journalperso.fr - Resend email - Write personal journals online and earn money with each paid access!" : "Journalperso.fr - Renvoi du mail - Ecrivez des journaux personnels en ligne et gagnez de l'argent à chaque accès payant!";
                return $retour;
                break;
            case "notifications":
                $retour = $langue == "en" ? "Journalperso.fr - Notifications - Become a journalist for our site." : "Journalperso.fr - Notifications - Devenez journaliste pour notre site.";
                return $retour;
                break;
            case "statistiques":
                $retour = $langue == "en" ? "Journalperso.fr - Statistics - Make money easily online by becoming a web editor. Free registration!" : "Journalperso.fr - Statistiques - Gagnez de l'argent facilement en ligne en devenant web rédacteur.. Inscirption gratuite!";
                return $retour;
                break;
            case "mentions-legales":
                $retour = $langue == "en" ? "Journalperso.fr - Mentions Legales - Write interesting articles or newspapers and easily earn money online!" : "Journalperso.fr - Mentions Legales - Ecrivez des articles ou des journaux interressants et gagnez de l'argent facilement sur internet!";
                return $retour;
                break;
            case "demande-paiement":
                $retour = $langue == "en" ? "Journalperso.fr - Payement - Create online personal journals and online diaries easily." : "Journalperso.fr - Demande de paiement - Créez des journaux personnels en ligne et des journaux intimes en ligne facilement.";
                return $retour;
                break;
            case "accueil-membre":
                $retour = $langue == "en" ? "Journalperso.fr - User home - Become web editor!" : "Journalperso.fr - Accueil membre - Devenez web rédacteur !";
                return $retour;
                break;
            case "creerunjournal":
                $retour = $langue == "en" ? "Journalperso.fr - Create a journal - Gagnez de l'argent en ligne générez des revenus facilement en publiant du contenu." : "Journalperso.fr - Creer un journal - Gagnez de l'argent en ligne générez des revenus facilement en publiant du contenu.";
                return $retour;
                break;
            case "parrainnage":
                $retour = $langue == "en" ? "Journalperso.fr - Sponsorship - Become web editor! Website dedicated to independent journalism..." : "Journalperso.fr - Parrainnage - Devenez web rédacteur ! Site dédié au journalisme independant...";
                return $retour;
                break;
            case "reglement":
                $retour = $langue == "en" ? "Journalperso.fr - Regulations - Devenez journaliste indépendant facilement sur notre site." : "Journalperso.fr - Reglement - Devenez journaliste indépendant facilement sur notre site.";
                return $retour;
                break;
            case "reglement2":
                $retour = $langue == "en" ? "Journalperso.fr - Regulations - Gagnez de l'argent en devenant journaliste independant!" : "Journalperso.fr - Reglement - Gagnez de l'argent en devenant journaliste independant!";
                return $retour;
                break;
            case "inscription":
                $retour = $langue == "en" ? "Journalperso.fr - Sign up - Write diaries or public journals and earn money." : "Journalperso.fr - Inscription - Ecrivez des journaux intimes ou publiques et gagnez de l'argent.";
                return $retour;
                break;
            case "connexion":
                $retour = $langue == "en" ? "Journalperso.fr - Sign in - Sell ​​newspapers and earn money." : "Journalperso.fr - Connexion - Vendez des journaux et gagnez de l'argent.";
                return $retour;
                break;
            case "parametre":
                $retour = $langue == "en" ? "Journalperso.fr - Settings - Become a web editor and sell newspapers online!" : "Journalperso.fr - Parametre - Devenez web rédacteur et vendez des journaux en ligne!";
                return $retour;
                break;
            case "accueil":
                $retour = $langue == "en" ? "Journalperso.fr - Write personnal journals online ! - Write as many personal journals as you want and publish them!" : "Journalperso.fr - Ecrivez des journaux en ligne ! - Ecrivez des journaux personnels autant que vous voulez et publiez les!";
                return $retour;
                break;
            case "validation-inscription":
                $retour = $langue == "en" ? "Journalperso.fr - Validate registration - Share your diaries online and make money." : "Journalperso.fr - Valider l'inscription - Faites connaitre vos journaux intimes en ligne et gagnez de l'argent.";
                return $retour;
                break;
            case "validation-connexion":
                $retour = $langue == "en" ? "Journalperso.fr - Confirm login - Become a journalist for our site and generate income." : "Journalperso.fr - Valider connexion - Devenez journaliste pour notre site et générez des revenus.";
                return $retour;
                break;
            case "paiement":
                $retour = $langue == "en" ? "Journalperso.fr - Payment - Be part of our community of freelance journalists." : "Journalperso.fr - Paiement - Faites partis de notre communauté de journalistes independants.";
                return $retour;
                break;
            case "paiement_valider":
                $retour = $langue == "en" ? "Journalperso.fr - Payment validated - Become web editor! Website dedicated to independent journalism..." : "Journalperso.fr - Paiement validé - Devenez web rédacteur ! Site dédié au journalisme independant...";
                return $retour;
                break;
            case "paiement-mdp-journal":
                $retour = $langue == "en" ? "Journalperso.fr - Payment code - Become a web editor easily and this in a few minutes!" : "Journalperso.fr - Paiement code - Devenez web rédacteur facilement et ceci en quelques minutes!";
                return $retour;
                break;
            case "page-mdps":
                $retour = $langue == "en" ? "Journalperso.fr - Validate your payment - Make money with our site." : "Journalperso.fr - Validez votre paiement - Gagnez de l'argent grace à notre site.";
                return $retour;
                break;
            case "recherche":
                $retour = $langue == "en" ? "Journalperso.fr - Search - Make money online thanks to our independent journalism site!" : "Journalperso.fr - Recherche - Gagnez de l'argent sur internet grace notre site de journalisme independant !";
                return $retour;
                break;
            case "motdepasse-oublie":
                $retour = $langue == "en" ? "Journalperso.fr - Forgot your password - Become a journalist on the web and earn money easily!" : "Journalperso.fr - Mot de passe oublié - Devenez journaliste sur le web et gagnez de l'argent facilement!";
                return $retour;
                break;
            case "modifier-journal":
                $retour = $langue == "en" ? "Journalperso.fr - Modifer journal - Become web editor!" : "Journalperso.fr - Modifier journal - Devenez web rédacteur ! ";
                return $retour;
                break;   
            case null:
                $retour = $langue == "en" ? "Journalperso.fr - Write personnal journals online!" : "Journalperso.fr - Ecrivez des journaux en ligne!";
                return $retour;
                break;
            default:
                $retour = $langue == "en" ? "Journalperso.fr - Write personnal journals online!" : "Journalperso.fr - Ecrivez des journaux en ligne!";
                return $retour;
        }
}
?>
<?php $langue = langue(); ?>
<h1 class="h1"><?php if($langue=="fr"){echo "Devenez journaliste en ligne - Statistiques";}elseif($langue=="en"){echo"Become an online journalist - Statistics";}?></h1>
<div class="contenu-centre">
<div>
    <?php if($langue=="fr"){echo "Votre solde:";}elseif($langue=="en"){echo"Your balance:";} ?> <strong><?php echo round(affiche_solde($_SESSION['id']), 2);; ?>€</strong><br>
    <?php if($langue=="fr"){echo "Nombre total de vues sur vos journaux:";}elseif($langue=="en"){echo"Total number of views on your journals";} ?> <strong><?php echo nbr_vues_journaux($_SESSION['id']); ?></strong><br>
</div>
<!--Load the AJAX API-->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawMultSeries);

function drawMultSeries() {
      var data = new google.visualization.DataTable();
      data.addColumn('date', 'Jours');
      data.addColumn('number', 'Visites');
      data.addColumn('number', 'Ventes');

      data.addRows([
        <?php affiche_semaine_stats($_SESSION['id']); ?>
      ]);

      var options = {
        title: 'Nombre de ventes et de vues'
      };

      var chart = new google.visualization.ColumnChart(
        document.getElementById('chart_div'));

      chart.draw(data, options);
    }
    </script>
    <!--Div that will hold the pie chart-->
    <div id="chart_div"></div>
</div>
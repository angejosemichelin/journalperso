<?php $langue = langue(); ?>
<h1 class="h1"><?php if($langue=="fr"){echo "Gagnez de l'argent en ligne - Renvoi du mail de validation de connexion a votre compte";}elseif($langue=="en"){echo"Make money online - Return the login validation email to your account";}?></h1>
<div class="contenu-centre">
<?php 
// renvoi le mail de validation de compte
renvoi_mail_validation_compte($_SESSION['id']);
if($langue=="fr"){echo "Un mail vous a été renvoyé. Verifiez vos spams.";}elseif($langue=="en"){echo"An email has been sent back to you. Verify your spams.";}
?>
</div>
<?php $langue = langue(); ?>
<h1 class="h1"><b><?php journal_perso_de($_SESSION['id']); ?></b> - <?php if($langue=="fr"){echo "Journal intime en ligne - Bienvenue sur votre compte Journalperso.fr";}elseif($langue=="en"){echo"Online diary - Welcome to your account Journalperso.fr";}?></h1>
<center><a class="hvr-grow" href="index-user.php?page=creerunjournal" alt="Créez votre premier journal personnel"><img class="boutonaide" src="ressources/img/bouton-aide.webp" alt="Créez votre premier journal" /></a></center>
<section style="margin-top:10px;" class="alert alert-info" role="alert">
<?php 
    if($langue=="fr"){
        echo "<strong>Devenez rédacteur web</strong> et <strong>gagnez de l'argent sur internet</strong>! Créez des journaux privés ou libres. Publiez ce que vous voulez (Images, Vidéos, Texte, Articles, Fichiers téléchargeable). Vos notes, vos pensées faites en un journal privé ou publiquec'est a dire un <strong>journal intime en ligne</strong> Vous pouvez faire payer l'accès à votre journal privé et recevoir de l'argent pour chaque accès a votre <strong>journal personnel</strong>. Alors au travail et soyer créatif! Vous pouvez même écrire un livre interactif! En écrivant un journal il sera présent sur le site et sur Google.";
    }elseif($langue=="en"){
        echo"<strong>Become a web editor</strong> and <strong>make money on the internet</strong>! Create journals to sell them later. Publish what you want (Images, Videos, Text, Articles, Downloadable File). Your notes, your thoughts done in a private journal or public. You can charge access to your <strong>diary</strong> and receive money for each access to your private journal. So, go work and be creative! You can even write an interactive book. By writing a newspaper he will be present on the site and on Google.";
    } 
?>
</section>
<img id="img_gagner_argent" src="ressources/img/Photo-Journalperso-texteetplante.webp" alt="Révélez vos talents sur notre site de journalisme independant et de rédacteurs web journalperso.fr. Soyez créatif!"/>
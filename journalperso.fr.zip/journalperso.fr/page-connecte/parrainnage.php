<?php $langue = langue(); ?>
<h1 class="h1"><?php if($langue=="fr"){echo "Journal personnel en ligne - Parrainage, pour gagnez plus gràce à notre site !";}elseif($langue=="en"){echo"Personal diary online - Sponsorship, to win more thanks to our site!";} ?></h1>
<div class="contenu-centre">
<style>
  @media screen and (max-width: 800px){
    .table-crea {
      width:350px;
      display:block;
      margin:0 auto;
    }
    .contenu-centre{
      padding:0;
    }
  }
</style>
<?php
    if($langue=="fr"){
        ?>
        <div style="text-align:center">
        <img src="ressources/img/illuminati.webp" alt="Image Illuminati Parrainnage Journalperso.fr" />
          <p>A chaque fois qu'un filleul de niveau 1 vend un journal vous toucher 30%.</p>
          <p>A chaque fois qu'un filleul de niveau 2 vend un journal vous toucher 10%.</p>
          <p>Utilisez les réseaux sociaux ou tout autres moyens de transmissions mise à votre disposition.</p>
          <p>Vous avez <b><?php echo nombre_filleul($_SESSION["id"]); ?></b> filleuls au total.</p>
          <br><br>
          <p>Votre lien de parrainage est le suivant: <a href="https://www.journalperso.fr?parrain=<?php echo $_SESSION['id']; ?>">https://www.journalperso.fr?parrain=<?php echo $_SESSION['id']; ?></a></p>
          <p>Voici une bannière de parrainage faites pour vous (installez la ou vous voulez):</p>
          <div class="table-crea table-responsive">
          <a href="https://www.journalperso.fr?parrain=<?php echo $_SESSION['id']; ?>"><img src="https://www.journalperso.fr/ressources/img/banniere-468-glob.png" alt="bannière Journalperso.fr"></a>
          <br><textarea cols="60"><a href="https://www.journalperso.fr?parrain=<?php echo $_SESSION['id']; ?>"><img src="https://www.journalperso.fr/ressources/img/banniere-468-glob.png" alt="bannière Journalperso.fr"></a></textarea>
          </div>
          </div>
        <?php
    }elseif($langue=="en"){
        ?>
        <div style="text-align:center">
        <img src="ressources/img/illuminati.webp" alt="Image Illuminati Parrainnage Journalperso.fr" />
            <p>Whenever a level 1 godson sells a newspaper you get 30%.</p>
            <p>Every time a level 2 godson sells a newspaper, you get 10%.</p>
            <p>Use social networks or any other means of communication available to you.</p>
            <p>You have <b><?php echo nombre_filleul($_SESSION["id"]); ?></b> godson.</p>
            <br><br>
            <p>Your referral link is: <a href="https://www.journalperso.fr?parrain=<?php echo $_SESSION['id']; ?>">https://www.journalperso.fr?parrain=<?php echo $_SESSION['id']; ?></a></p>
          <p>Here is a sponsorship banner made for you (install where you want):</p>
          <div class="table-crea table-responsive">
          <a href="https://www.journalperso.fr?parrain=<?php echo $_SESSION['id']; ?>"><img src="https://www.journalperso.fr/ressources/img/banniere-468-glob-en.png" alt="bannière Journalperso.fr"></a>
          <br><textarea cols="60"><a href="https://www.journalperso.fr?parrain=<?php echo $_SESSION['id']; ?>"><img src="https://www.journalperso.fr/ressources/img/banniere-468-glob-en.png" alt="bannière Journalperso.fr"></a></textarea>
          </div></div>
        <?php
    }
?>
</div>
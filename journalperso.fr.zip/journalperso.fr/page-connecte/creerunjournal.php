<?php $langue = langue(); ?>
<h1 class="h1"><?php if($langue=="fr"){echo "Journal personnel en ligne - Créer un journal personnel";}elseif($langue=="en"){echo"Personal diary online - Create a personnel journal";}?></h1>
<div class="contenu-centre">
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg btncreer" data-toggle="modal" data-target="#creer">
  --- <?php if($langue=="fr"){echo "Creer un journal";}elseif($langue=="en"){echo "Create a journal";}?> ---
</button>
<p class="aligncenter"><?php if($langue=="fr"){echo "En écrivant un journal il sera présent sur le site et sur Google.";}elseif($langue=="en"){echo "By writing a newspaper he will be present on the site and on Google.";}?></p>
<!-- Modal -->
</div>
<?php
// Si un article est publié par la methode post on execute la fonction publier_text
    if (isset($_POST["nom_journal"]) && isset($_POST["description"]) && isset($_POST["themes"])){
        if(!empty($_POST["description"]) && !empty($_POST["nom_journal"]) && strlen($_POST['nom_journal']) < 60 && strlen($_POST['description']) < 400 && $_POST["themes"] > 0 && $_POST["themes"] <= 26){
            $nom_journal = filter_input(INPUT_POST, 'nom_journal', FILTER_SANITIZE_STRING);
            $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
            $theme = filter_input(INPUT_POST, 'themes', FILTER_SANITIZE_STRING);
            creer_journal($_SESSION["id"], $description, $nom_journal, $theme);
            notifier($_SESSION['id'], "Vous avez créez le journal ".$nom_journal);
        } else {
            echo "Veuillez remplir correctement le formulaire.";
        }
    }
?>
<?php
// on peut supprimer une publication
if (isset($_GET["suppr-id"])){
    $id_journal = $_GET["suppr-id"];
    supprimmer_journal($id_journal);
}
// on affiche le modal suppression ou creation
if (isset($_GET["modal"])){
  if($_GET["modal"] == "create"){
    modal("Journal créé.");
  }elseif($_GET["modal"] == "delete"){
    modal("Journal supprimé.");
  }
}
?>
<div class="modal fade" id="creer" tabindex="-1" role="dialog" aria-labelledby="creer" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    <form action="index-user.php?page=creerunjournal" method="post">
      <div class="modal-header">
        <h5 class="modal-title" id="creer"><?php if($langue=="fr"){echo "Créer un journal";}elseif($langue=="en"){echo "Create a journal";}?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php
            if($langue=="fr"){
                input("text", "Nom du Journal:", "nom_journal", "nom_journal", "Nom du Journal", true, "", "minlength='4' maxlength='50'");
            }elseif($langue=="en"){
                input("text", "Name of Journal:", "nom_journal", "nom_journal", "Nom du Journal", true, "", "minlength='4' maxlength='50'");
            }
        ?>
      <div class="form-group">
        <label for="themes"><?php if($langue=="fr"){echo "Thèmes";}elseif($langue=="en"){echo "Themes";}?></label>
        <select name="themes" class="form-control">
          <option value="1">Gagner de l'argent</option>
          <option value="2">Vie privée</option>
          <option value="3">Santé</option>
          <option value="4">Sport</option>
          <option value="5">Medecine</option>
          <option value="6">Actualité</option>
          <option value="7">Vie quotidienne</option>
          <option value="8">Infos utiles</option>
          <option value="9">Littérature</option>
          <option value="10">Ecriture créative</option>
          <option value="11">Poèmes</option>
          <option value="12">Photographie</option>
          <option value="13">Musique</option>
          <option value="14">Films</option>
          <option value="15">Internet</option>
          <option value="16">Histoire</option>
          <option value="17">Scolaire</option>
          <option value="18">Informatique</option>
          <option value="19">Sciences</option>
          <option value="20">Economie</option>
          <option value="21">Réseaux sociaux</option>
          <option value="22">Profession par métiers</option>
          <option value="23">Divertissement</option>
          <option value="24">Jeux</option>
          <option value="25">Hot</option>
          <option value="26">Autres</option>
       </select>
      </div>
      <div class="form-group">
        <label for="description"><?php if($langue=="fr"){echo "Description";}elseif($langue=="en"){echo "Description";}?></label>
        <textarea class="form-control" minlength='4' maxlength='200' name="description" id="description" rows="3"></textarea>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php if($langue=="fr"){echo "Fermer";}elseif($langue=="en"){echo "Close";}?></button>
        <button type="submit" class="btn btn-primary"><?php if($langue=="fr"){echo "Enregistrer";}elseif($langue=="en"){echo "Save";}?></button>
      </div>
      </form>
    </div>
  </div>
</div>
<div class="table-responsive">
<table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"><?php if($langue=="fr"){echo "Nom du Journal";}elseif($langue=="en"){echo "Name of journal";}?></th>
      <th scope="col"><?php if($langue=="fr"){echo "Thème";}elseif($langue=="en"){echo "Theme";}?></th>
      <th scope="col"><?php if($langue=="fr"){echo "Nombre de vues";}elseif($langue=="en"){echo "Number of views";}?></th>
      <th scope="col"><?php if($langue=="fr"){echo "Options";}elseif($langue=="en"){echo "Options";}?></th>
    </tr>
  </thead>
  <tbody>
  <?php 
    //Affiche les journaux créé dans le tableau
    afficher_les_journaux($_SESSION["id"]);
  ?>
  </tbody>
</table>
</div>
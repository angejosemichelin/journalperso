﻿<?php $langue = langue(); ?>
<h1 class="h1"><?php if($langue=="fr"){echo "Site de journalisme indépendant - Jeux en ligne: Ticket gagnant";}elseif($langue=="en"){echo"Independent Journalism Site - Online Games: Winning Ticket";}?></h1>
<div id="ticketagratter">
    <p><?php if($langue=="fr"){echo "Vous avez une chance sur 2 de gagner.";}elseif($langue=="en"){echo"You have a one-in-two chance of winning.";}?></p>
    <a href="index-user.php?page=jeux&type=ticket10" alt="Ticket à 0.10€">Ticket 0.10€</a>
    <a href="index-user.php?page=jeux&type=ticket50" alt="Ticket à 0.50€">Ticket 0.50€</a>
    <a href="index-user.php?page=jeux&type=ticket1" alt="Ticket à 1€">Ticket 1€</a>
    <a href="index-user.php?page=jeux&type=ticket5" alt="Ticket à 5€">Ticket 5€</a>
    <a href="index-user.php?page=jeux&type=ticket10e" alt="Ticket à 10€">Ticket 10€</a>
</div>
<div id="resultat-ticket">
<?php
        $id_user = $_SESSION["id"];
        if($_GET["type"] == "ticket10"){
            if(affiche_solde($id_user) >= 0.1){
                ?>
                <a type="button" href="index-user.php?page=jeux&jouer=0.1" class="btn btn-primary btn-sm">Jouer 0.10€</a>
                <?php
            } else {
                if($langue=="fr"){echo "Votre solde est insuffisant.";}elseif($langue=="en"){echo"Your balance is insufficient.";}
            }
        } elseif($_GET["type"] == "ticket50"){
            if(affiche_solde($id_user) >= 0.1){
                ?>
                <a type="button" href="index-user.php?page=jeux&jouer=0.5" class="btn btn-primary btn-sm">Jouer 0.50€</a>
                <?php
            } else {
                if($langue=="fr"){echo "Votre solde est insuffisant.";}elseif($langue=="en"){echo"Your balance is insufficient.";}
            }
        } elseif($_GET["type"] == "ticket1"){
            if(affiche_solde($id_user) >= 0.1){
                ?>
                <a type="button" href="index-user.php?page=jeux&jouer=1" class="btn btn-primary btn-sm">Jouer 1€</a>
                <?php
            } else {
                if($langue=="fr"){echo "Votre solde est insuffisant.";}elseif($langue=="en"){echo"Your balance is insufficient.";}
            }
        } elseif($_GET["type"] == "ticket5"){
            if(affiche_solde($id_user) >= 0.1){
                ?>
                <a type="button" href="index-user.php?page=jeux&jouer=5" class="btn btn-primary btn-sm">Jouer 5€</a>
                <?php
            } else {
                if($langue=="fr"){echo "Votre solde est insuffisant.";}elseif($langue=="en"){echo"Your balance is insufficient.";}
            }
        } elseif($_GET["type"] == "ticket10e"){
            if(affiche_solde($id_user) >= 0.1){
                ?>
                <a type="button" href="index-user.php?page=jeux&jouer=10" class="btn btn-primary btn-sm">Jouer 10€</a>
                <?php
            } else {
                if($langue=="fr"){echo "Votre solde est insuffisant.";}elseif($langue=="en"){echo"Your balance is insufficient.";}
            }
        }

        if($_GET["jouer"]){
            if($_GET["jouer"] == 0.1 || $_GET["jouer"] == 0.5 || $_GET["jouer"] == 1 || $_GET["jouer"] == 5 || $_GET["jouer"] == 10){
                if(affiche_solde($id_user) >= $_GET["jouer"]){
                    notifier($id_user, "Ticket à gratter ".$_GET["jouer"]."€");
                    if(resultat_ticket() == true){
                        crediter($_GET["jouer"], $id_user, "Ticket à gratter pour ".$id_user);
                        if($langue=="fr"){echo "Gagné.";}elseif($langue=="en"){echo"Won.";}
                    }else{
                        debiter($_GET["jouer"], $id_user, "Ticket à gratter pour ".$id_user);
                        if($langue=="fr"){echo "Perdu.";}elseif($langue=="en"){echo"Lost.";}
                    }
                } else {
                    if($langue=="fr"){echo "Votre solde est insuffisant.";}elseif($langue=="en"){echo"Your balance is insufficient.";}
                }
            }
        }
?>
</div>
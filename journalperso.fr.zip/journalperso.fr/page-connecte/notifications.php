<?php $langue = langue(); ?>
<h1 class="h1"><?php if($langue=="fr"){echo "Journal intime en ligne - Notifications de votre compte";}elseif($langue=="en"){echo"Online diary - Notifications from your account";} ?></h1>
<div style="font-size:0.9em;">
<?php 
notifications($_SESSION["id"]);
efface_vue($_SESSION["id"]);
?>
</div>
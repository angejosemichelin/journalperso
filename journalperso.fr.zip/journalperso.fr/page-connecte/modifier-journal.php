    <?php 
    $langue = langue(); 
        // on recupère l'id du journal
    $id_journal = $_GET["id"];
    $id_user_journal = id_user_de_journal($id_journal);
    if($id_user_journal == $_SESSION["id"]){
        ?>
        <h1 class="h1"><?php if($langue=="fr"){echo "Gagnez de l'argent en ligne - Ecrire votre journal personnel: ".recuperer_nom_journal($id_journal);}elseif($langue=="en"){echo"Make money online - Write your personnel journal: ".recuperer_nom_journal($id_journal);} ?></h1>
        <div class="container">
            <div class="row">
                <div class="col-sm text-center" style="vertical-align:center;">
                <?php
                if(isset($_POST["mot_de_passe_journal"])){
                    $valeurs = [
                        'mot_de_passe_journal' => $_POST["mot_de_passe_journal"],
                        'id' => $id_journal
                    ];
                    update_bdd("UPDATE journaux SET mot_de_passe = :mot_de_passe_journal WHERE id = :id", $valeurs);
                    modal("Le mot de passe du journal à changer.");
                }
                ?>
                <form style="width:300px;margin:0 auto;display:block;" action="index-user.php?page=modifier-journal&id=<?php echo $id_journal; ?>" method="post">
                    <?php
                    if($langue=="fr"){
                        input("password", "Mot de passe de votre journal personnel:", "mot_de_passe_journal", "mot_de_passe_journal", recuperer_mot_de_passe_journal($id_journal), true, "", "");
                    }elseif($langue=="en"){
                        input("password", "Password of your journal personnel:", "mot_de_passe_journal", "mot_de_passe_journal", recuperer_mot_de_passe_journal($id_journal), true, "", "");
                    }
                    ?>
                    <center><button class="btn btn-primary" type="submit"><?php if($langue=="fr"){echo "Modifier";}elseif($langue=="en"){echo"Edit";} ?></button></center>
                </form>
                </div>
                <div class="col-sm">
                <center style="margin-top:10px"><?php if($langue=="fr"){echo "Vous gagnez 1euro par accès payant.";}elseif($langue=="en"){echo"You earn 1 dollar per paid access.";} ?></center>
                <?php
                    // Classé la personne
                    if (isset($_GET['payant']))
                    {
                        if($_GET['payant'] == "1"){
                            etre_payant($id_journal, 1);
                            modal("Le journal personnel est maintenant payant.");
                        } elseif($_GET['payant'] == "0"){
                            etre_payant($id_journal, 0);
                            modal("Le journal personnel est maintenant gratuit.");
                        }
                    }
                    if(payant($id_journal) == "1"){
                        ?>
                        <a class="a_button" href="index-user.php?page=modifier-journal&id=<?php echo $id_journal; ?>&payant=0"><?php if($langue=="fr"){echo "Passer en journal personnel gratuit";}elseif($langue=="en"){echo"Switch to free journal";} ?></a>
                        <?php
                    } elseif(payant($id_journal) == "0"){
                        ?>
                        <a class="a_button" href="index-user.php?page=modifier-journal&id=<?php echo $id_journal; ?>&payant=1"><?php if($langue=="fr"){echo "Passer en journal personnel payant";}elseif($langue=="en"){echo"Switch to paying journal";} ?></a>
                        <?php
                    }
                ?>
                </div>
            </div>
        </div>
        <div class="alert alert-info margintop10" role="alert">
            <strong><?php if($langue=="fr"){echo "Lien pour partager votre journal personnel:";}elseif($langue=="en"){echo"Link to share your personnal journal:";} ?></strong> <a href="http://www.journalperso.fr/journal<?php echo $id_journal;?>" target="_blank" alt="<?php echo recuperer_nom_journal($id_journal); ?>">http://www.journalperso.fr/journal<?php echo $id_journal;?></a>
        </div>

    <!-- BLOC FORMULAIRE PUBLIER -->
    <div id="publier">
        <div id="ecrire_texte">
            <h3 class="memoplay"><b>MEMO PLAY</b></h3>
            <div id="tabs">
                <ul>
                    <li><a href="#tabs-1"><?php if($langue=="fr"){echo "Ecrire";}elseif($langue=="en"){echo"Write";} ?></a></li>
                    <li><a href="#tabs-3"><?php if($langue=="fr"){echo "Dessiner";}elseif($langue=="en"){echo"Draw";} ?></a></li>
                    <li><a href="#tabs-2"><?php if($langue=="fr"){echo "Télécharger";}elseif($langue=="en"){echo"Download";} ?></a></li>
                </ul>
                <div class="aligncenter" id="tabs-1">
                    <?php if($langue=="fr"){echo "Uniquement sur PC";}elseif($langue=="en"){echo"Only on PC";} ?>
                    <div id="div_texte_pc">
                        <form action="" method="post">
                            <div class="align-center-90" class="input-group">
                                <textarea class="form-control" rows="4" id="texte" name="texte" aria-label="Votre texte"></textarea>
                            </div>
                            <input type="hidden" name="publier_text_pc" value="true" />
                            <center><button type="submit" class="publier_btn btn btn-primary"><?php if($langue=="fr"){echo "Publier";}elseif($langue=="en"){echo"Publish";} ?></button></center>
                        </form>
                    </div>
                    <div id="div_texte_smartphone">
                        <form action="" method="post">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><?php if($langue=="fr"){echo "Taper:";}elseif($langue=="en"){echo"Type:";} ?></span>
                                </div>
                                <textarea class="form-control" rows="4" name="texte" aria-label="Votre texte"></textarea>
                            </div>
                            <input type="hidden" name="publier_text_smartphone" value="true" />
                            <center><button type="submit" class=" publier_btn btn btn-primary"><?php if($langue=="fr"){echo "Publier";}elseif($langue=="en"){echo"Publish";} ?></button></center>
                        </form>
                    </div>
                </div>
                <div id="tabs-2">
                    <form enctype="multipart/form-data" action="index-user.php?page=modifier-journal&id=<?php echo $id_journal; ?>" method="POST">
                        <div class="telecharger" class="form-group">
                            <p><?php if($langue=="fr"){echo "Modifiez le nom de votre document en fonction de ce qu'il contient. Exemple: chateau-versaille.png, bonjour.gif, video_presentation.webm, document.txt";}elseif($langue=="en"){echo"Change the name of your file according to what it contains. Example: chateau-versaille.png, bonjour.gif, video_presentation.webm, document.txt";} ?></p>
                            <div class="input-file-container" style="margin:0 auto;display:block;">
                            <input class="input-file" name="upload_file" id="my-file" type="file">
                            <label for="my-file" class="input-file-trigger" tabindex="0">Select a file</label>
                            </div>
                            <p class="file-return"></p>
                            <?php
                            if($langue=="fr"){
                                input("text", "Decrivez votre document:", "description_file", "description_file", "Decrivez votre document", true, "", "minlength='4' maxlength='50'");
                            }elseif($langue=="en"){
                                input("text", "Describe your document:", "description_file", "description_file", "Describe your document", true, "", "minlength='4' maxlength='50'");
                            }
                            ?>
                        </div>
                        <center><input type="submit" class="publier_btn btn btn-primary" value="<?php if($langue=="fr"){echo "Télécharger et publier";}elseif($langue=="en"){echo"Download and publish";} ?>"></center>
                    </form>
                </div>
                <div class="aligncenter" id="tabs-3">
                    <?php if($langue=="fr"){echo "Uniquement sur PC";}elseif($langue=="en"){echo"Only on PC";} ?>
                    <div id="div_dessin">
                        <div class="palette">
                            Couleurs: 
                            <span onclick="changecouleur('#000'); bigHeight('4')" style="background:#000"></span>
                            <span onclick="changecouleur('#606060'); bigHeight('4')" style="background:#606060"></span>
                            <span onclick="changecouleur('#AAAAAA'); bigHeight('4')" style="background:#AAAAAA"></span>
                            <span onclick="changecouleur('#FFF'); bigHeight('4')" style="background:#FFF"></span>
                            <span onclick="changecouleur('#FF0000'); bigHeight('4')" style="background:#FF0000"></span>
                            <span onclick="changecouleur('#FF8000'); bigHeight('4')" style="background:#FF8000"></span>
                            <span onclick="changecouleur('#FFFF00'); bigHeight('4')" style="background:#FFFF00"></span>
                            <span onclick="changecouleur('#80FF00'); bigHeight('4')" style="background:#80FF00"></span>
                            <span onclick="changecouleur('#00FF00'); bigHeight('4')" style="background:#00FF00"></span>
                            <span onclick="changecouleur('#00FF80'); bigHeight('4')" style="background:#00FF80"></span>
                            <span onclick="changecouleur('#00FFFF'); bigHeight('4')" style="background:#00FFFF"></span>
                            <span onclick="changecouleur('#0080FF'); bigHeight('4')" style="background:#0080FF"></span>
                            <span onclick="changecouleur('#0000FF'); bigHeight('4')" style="background:#0000FF"></span>
                            <span onclick="changecouleur('#8000FF'); bigHeight('4')" style="background:#8000FF"></span>
                            <span onclick="changecouleur('#FF00FF'); bigHeight('4')" style="background:#FF00FF"></span>
                            <span onclick="changecouleur('#FF0080'); bigHeight('4')" style="background:#FF0080"></span>
                        </div>
                        <div class="gomme">
                            Gomme: <span onclick="changecouleur('#FFF'); bigHeight('300')" style="background:#FFF"></span>
                        </div>
                        <div id="div_dessin">
                            <p id="id_journal" class="displaynone"><?php echo $id_journal; ?></p>
                            <?php
                            if($langue=="fr"){
                                input("text", "Decrivez votre dessin:", "description_dessin", "description_dessin", "Decrivez votre dessin", true, "", "minlength='4' maxlength='50'");
                            }elseif($langue=="en"){
                                input("text", "Describe your drawing:", "description_dessin", "description_dessin", "Describe your dessin", true, "", "minlength='4' maxlength='50'");
                            }
                            ?>
                            <canvas id="dessin" width="500" height="300"></canvas> 
                            <center><input id="publier_dessin" class=" publier_btn btn btn-primary" value="<?php if($langue=="fr"){echo "Publier";}elseif($langue=="en"){echo"Publish";} ?>"></center>
                            <script>
                                $("#publier_dessin").click(function(){
                                    $.ajax({
                                        type: "POST",
                                        url: 'page-connecte/envoi_canvas.php',
                                        dataType: 'text',
                                        data:  {
                                            image : document.getElementById("dessin").toDataURL(),
                                            id : document.getElementById("id_journal").innerHTML,
                                            description: document.getElementById("description_dessin").value
                                        }
                                    });
                                    window.alert('<?php if($langue=="fr"){echo "Pour voir votre dessin cliquez ici.";}elseif($langue=="en"){echo"To see your drawing click here.";} ?>');
                                    window.location.reload(true);
                                });
                            </script>
                        </div>  
                    </div>   
                </div>
            </div>
        </div>
        <br>
        <?php
        
        // on recupère l'id de l'utilisateur
        $id_user = $_SESSION["id"];

        // Si un article est publié par la methode post on execute la fonction publier_text
        if (isset($_POST["publier_text_pc"]) && !empty($_POST["texte"])){
            $texte = $_POST["texte"];
            // On publie
            publier($texte, $id_journal, "", "texte");
            $validation = "Texte publié.";
            modal($validation);
        }

        // Si un article est publié par la methode post on execute la fonction publier_text
        if (isset($_POST["publier_text_smartphone"]) && !empty($_POST["texte"])){
            $texte = filter_input(INPUT_POST, 'texte', FILTER_SANITIZE_STRING);
            // On publie
            publier($texte, $id_journal, "", "texte");
            $validation = "Texte publié.";
            modal($validation);
        }

        // on upload les videos
        if(!empty($_FILES['upload_file'])){
            if(isset($_POST["description_file"])){
                $type = $_FILES['upload_file']['type'];
                $size = $_FILES['upload_file']['size'];
                $size_max = 1048576*50;
                $type_reel = "";
                switch($type){
                    case "audio/wav":
                        $type_reel = "son";
                        $path = "publications/sons/";
                        break;
                    case "audio/ogg":
                        $type_reel = "son";
                        $path = "publications/sons/";
                        break;
                    case "audio/mpeg":
                        $type_reel = "son";
                        $path = "publications/sons/";
                        break;
                    case "image/png":
                        $type_reel = "image";
                        $path = "publications/iùmages/";
                        break;
                    case "image/jpeg":
                        $type_reel = "image";
                        $path = "publications/images/";
                        break;
                    case "image/gif":
                        $type_reel = "image";
                        $path = "publications/images/";
                        break;
                    case "video/mp4":
                        $type_reel = "video";
                        $path = "publications/videos/";
                        break;
                    case "video/webm":
                        $type_reel = "video";
                        $path = "publications/videos/";
                        break;
                    case "video/ogg":
                        $type_reel = "video";
                        $path = "publications/videos/";
                        break;
                    default:
                        $type_reel = "fichier";
                        $path = "publications/fichiers/";
                }
                $path = $path . basename($_FILES['upload_file']['name']);
                if($size < $size_max){
                    if(move_uploaded_file($_FILES['upload_file']['tmp_name'], $path)) {
                        publier($path, $id_journal, $_POST["description_file"], $type_reel);
                        $validation = "Le $type_reel est publiée.";
                        modal($validation);           
                    } else {
                        $validation = "Erreur lors du téléchargement du document";
                        modal($validation); 
                    }
                } else {
                    $validation = "Erreur fichier trop gros.";
                    modal($validation); 
                }
            } else {
                $validation = "Erreur dans le forumalaire. Decrivez vortre fichier.";
                modal($validation);
            }
        }
        ?>
        <?php
        // on peut supprimer une publication
        if (isset($_GET["suppr-id"])){
            $id_message = $_GET["suppr-id"];
            supprimmer_publication($id_message);
        }
        // appel a la fonction
        afficher_publications_compte($id_journal);
        ?>
        <script type="text/javascript">
        // Gère la tabulation du MemoPlay
        $(function() {
            $("#tabs").tabs();
        });
        $(document).ready(function(){
            $("#texte").cleditor();
        });  
    </script>
    <script>
        
    // ajout de la classe JS à HTML
    document.querySelector("html").classList.add('js');
    
    // initialisation des variables
    var fileInput  = document.querySelector( ".input-file" ),  
        button     = document.querySelector( ".input-file-trigger" ),
        the_return = document.querySelector(".file-return");
    
    // action lorsque la "barre d'espace" ou "Entrée" est pressée
    button.addEventListener( "keydown", function( event ) {
        if ( event.keyCode == 13 || event.keyCode == 32 ) {
            fileInput.focus();
        }
    });
    
    // action lorsque le label est cliqué
    button.addEventListener( "click", function( event ) {
        fileInput.focus();
        return false;
    });
    
    // affiche un retour visuel dès que input:file change
    fileInput.addEventListener( "change", function( event ) {  
        the_return.innerHTML = this.value;  
    });
    
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
    <script type="text/javascript" src="ressources/js/resize_image.js"></script>
    <script type="text/javascript" src="ressources/js/canvas.js"></script>
    <?php } ?>
    </div>
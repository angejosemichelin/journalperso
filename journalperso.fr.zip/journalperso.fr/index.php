<?php

    // On inclus les fonctions php

    include('fonctions/fonctions.php');



    // Ouvrir session

    ouvrir_session();



    enligne();



    // on recupère le parrain et la langue par defaut

    if(isset($_GET["parrain"])){

        setcookie("parrain", $_GET["parrain"]);

    }



    $langue = langue();

?>

<!DOCTYPE html>

    <head>

    <?php 

        $page = isset($_GET["page"]) ? $_GET["page"] : null;

        $titre_page = titre_page($page);

        $description_page = description_page($page);

        afficher_head($titre_page, $description_page);

    ?>

    </head>

    <div id="fb-root"></div>

    <body>

<!-- WRAPPER -->

<div id="wrapper">

   <!-- HEADER -->

    <header>

        <div class="langues">

            <a id="fr" style="z-index:10000" href="#"><img src="ressources/img/francais.webp" alt="Passer en langue française sur le site internet journalperso.fr" /></a>

            <a id="en" style="z-index:10000" href="#"><img src="ressources/img/anglais.webp" alt="Passer en langue anglaise sur le site internet journalperso.fr" /></a> 

        </div>

        <div id="div_logo">

                    <div style="position:relative">

                    <a href="https://www.journalperso.fr"><img class="logo" src="ressources/img/logo.webp" alt="Logo of the site internet Journalperso.fr - Website of independent journalism and web editors!" /></a>

                    <img style="position:absolute;right:60px;top:15px" src="ressources/img/etoile.webp" alt="Etoiles scitillante"/>

                    </div>

        </div>

        <div id="conteneur_pub">

            <div id="pub">
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- annonce principale -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:90px"
     data-ad-client="ca-pub-1499321886222382"
     data-ad-slot="9836787028"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
            </div>

        </div>

    </header>

            <!-- NAVBAR -->

            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">

                <a class="navbar-brand" href="index.php?page=accueil"><img src="ressources/img/accueil.webp" alt="Accueil menu"/></a>

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

                    <span class="navbar-toggler-icon"></span>

                </button>



                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <ul class="navbar-nav mr-auto">

                    <li class="nav-item">

                        <a class="nav-link" href="index.php?page=accueil"><?php if($langue=="fr"){echo "Accueil";}elseif($langue=="en"){echo"Home";} ?></a>

                    </li>

                    <li class="nav-item">

                        <a class="nav-link" href="index.php?page=inscription"><?php if($langue=="fr"){echo "Devenez rédacteur web!";}elseif($langue=="en"){echo"Become a web editor!";} ?></a>

                    </li>

                    <li class="nav-item">

                        <a class="nav-link" href="index.php?page=touslesjournaux"><?php if($langue=="fr"){echo "Tous nos journaux!";}elseif($langue=="en"){echo"All our newspapers!";} ?></a>

                    </li>

                    <li class="nav-item">

                        <a class="nav-link" href="index.php?page=avis"><?php if($langue=="fr"){echo "Avis et témoignages";}elseif($langue=="en"){echo"Opinions and testimonials";} ?></a>

                    </li>

                    <li class="nav-item">

                        <a class="nav-link" href="index.php?page=connexion"><?php if($langue=="fr"){echo "Connexion";}elseif($langue=="en"){echo"Log in";} ?></a>

                    </li>

                    </ul>

                </div>

            </nav>

            <section id="contenu" class="positionrelative paddingbottom60">

            <?php

                // gérer les pages

                $page = isset($_GET["page"]) ? $_GET["page"] : null;

                gerer_les_pages(false, $page);

            ?>

                <div id="publicite">

                    <?php afficher_publicite() ?>

                </div>

            </section>

        </div>

        <!-- FOOTER -->

        <footer>

            <?php afficher_footer(); ?>

        </footer>

          <div id="chargement">

           <img src="ressources/img/chargement.webp" alt="chargement"/>

         </div>

        <script>

            $(window).on('load', function(){

                $("#chargement img").css("display", "none");

            });

        </script>

    </body>

</html>
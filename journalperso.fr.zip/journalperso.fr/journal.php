<?php

// On inclus les fonctions php

include('fonctions/fonctions.php');

$langue = langue();

enligne();

?>

<!DOCTYPE html>

<html>

<head>

    <?php 

    // on recupère l'id du journal

    $id_journal = isset($_GET["id"]) ? $_GET["id"] : null;

    // on recupère le nom et prenom de l'utilisateur

    $nom_prenom = nom_prenom_de_journal($id_journal);

    // on recupere le nom du journal

    $nom_journal = recuperer_nom_journal($id_journal);

    // on recupere la description

    $description_journal = recuperer_description_journal($id_journal);

    if($langue=="fr"){$texte="Journal personnel de ".$nom_prenom;}elseif($langue=="en"){$texte="Personnal journal of ".$nom_prenom;}

    afficher_head("Journalperso.fr - ".$nom_journal, $texte); 

    if(isset($_POST["mot_de_passe_journal"])){

        if($_POST["mot_de_passe_journal"] == mot_de_passe($id_journal)){

        $acceder_journal = true;

        } else {

        $acceder_journal = false;

        }

    } else {

        $acceder_journal = false;

    }

    ?> 

    <style>

        img {

            cursor: zoom-in;

        }
        html { overflow-y:visible; } 
    </style>
</head>

<body>

<!-- WRAPPER -->

<div id="wrapper2">

<header>

        <div class="langues">

            <a id="fr" style="z-index:10000" href="#"><img class="no-fullscreen cursorpointer" src="ressources/img/francais.webp" alt="Passer en langue française sur le site internet journalperso.fr" /></a>

            <a id="en" style="z-index:10000" href="#"><img class="no-fullscreen cursorpointer" src="ressources/img/anglais.webp" alt="Passer en langue anglaise sur le site internet journalperso.fr" /></a> 

            <a href="#" OnClick="javascript:window.print()"><img class="no-fullscreen cursorpointer" src="ressources/img/imprimer.webp" alt="Imprimer un journal personnel"/></a>

        </div>

        <div id="div_logo">

                    <div style="position:relative">

                    <a href="https://www.journalperso.fr"><img class="no-fullscreen logo cursorpointer" src="ressources/img/logo.webp" alt="Logo of the site internet Journalperso.fr - Website of independent journalism and web editors!" /></a>

                    <img style="position:absolute;right:60px;top:15px" class="no-fullscreen cursorpointer" src="ressources/img/etoile.webp" alt="Etoiles scitillante"/>

                    </div>

        </div>

        <div id="conteneur_pub">

            <div id="pub">
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- annonce principale -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:90px"
     data-ad-client="ca-pub-1499321886222382"
     data-ad-slot="9836787028"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
            </div>

        </div>

    </header>

<div id="contenu">
<?php  

if($acceder_journal){
    ?>
        <style>
            html { overflow-y:visible} 
        </style>
    <?php
}
    ?>
    <?php  

    if(!$acceder_journal){

        if(payant($id_journal) == 1){

        ?>
        <style>
            html { overflow-y: hidden; } 
        </style>
        <div class="fond_gris"></div>

        <div class="modal messsage_fond_gris" tabindex="-1" role="dialog">

            <div class="modal-dialog" role="document">

                <div class="modal-content">

                    <div class="modal-header">

                    <h5 class="modal-title"><strong><?php echo $nom_journal; ?></strong></h5>
                    
                    </div>

                    <div class="modal-body">
                    <p><?php echo $description_journal ?></p><br>
                        <form action="journal.php?id=<?php echo $id_journal; ?>" method="post">

                            <?php

                            if($langue=="fr"){

                                input("password", "Mot de passe du journal:", "mot_de_passe_journal", "mot_de_passe_journal", "Entrez le mot de passe du journal", true, "", "minlength='4' maxlength='50'");

                            }elseif($langue=="en"){

                                input("password", "Password of the journal:", "mot_de_passe_journal", "mot_de_passe_journal", "Enter the password of the journal", true, "", "minlength='4' maxlength='50'");

                            }

                            ?>

                            <center><button class="btn btn-primary aligncenter" type="submit"><?php if($langue=="fr"){echo "Acceder au journal";}elseif($langue=="en"){echo"Access to journal";} ?></button></center>

                        </form>

                    </div>

                    <div class="modal-footer">

                    <a href="index.php?page=paiement-mdp-journal&id=198<?php echo $id_journal; ?>" class=" btn btn-primary"><?php if($langue=="fr"){echo "Obtenir le code";}elseif($langue=="en"){echo"Get the code";} ?></a>

                    </div>

                </div>

            </div>

        </div>

        <?php

        }  

    }      

    // On affichage le nom du détenteur du journal personnel

    ?>

    <h1 class="h1"><?php if($langue=="fr"){echo "Devenez web rédacteur - Journal personnel: ";}elseif($langue=="en"){echo"Become web editor - Personal journal: ";} ?> <?php echo $nom_journal; ?></h1>

    <?php

    //On ajoute une vue

    $date_du_jour = date("Y-m-d");

    $adresse_ip = $_SERVER['REMOTE_ADDR'];

    ajouter_vue_journal($adresse_ip, $date_du_jour, $id_journal);

    ?>

    <center>

        <h2>Journal rédigé par <?php echo $nom_prenom; ?></h2>

        <p><?php echo $description_journal; ?></p>

    </center>

    <!-- Modal -->

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

        <div class="modal-dialog" role="document">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel"><?php if($langue=="fr"){echo "Ecrire un commentaire";}elseif($langue=="en"){echo"Write a comment";} ?></h5>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                    </button>

                </div>

                <div class="modal-body">

                    <form action="" method="post">

                    <?php

                    if($langue=="fr"){

                        input("text", "Nom et prénom:", "nom_prenom_com", "nom_prenom_com", "Nom et prénom", true, "", "minlength='4' maxlength='50'");

                    }elseif($langue=="en"){

                        input("text", "Last name and first name:", "nom_prenom_com", "nom_prenom_com", "Last name and first name", true, "", "minlength='4' maxlength='50'");

                    }

                    ?>

                    <label><?php if($langue=="fr"){echo "Commentaire:";}elseif($langue=="en"){echo"Comment:";} ?></label>

                    <textarea class="form-control" rows="4" id="commentaire" name="commentaire" required aria-label="Ecrire un commentaire..."></textarea>

                    <script>

                    function envoi_data(idpub){

                        $('#data').append('<input type="hidden" name="idpub" value="'+idpub+'">');

                    }

                    </script>

                    <div id="data"></div><br>

                    <div class="g-recaptcha" data-sitekey="6LcSRXEUAAAAAAMk7u5oZGHx1QtV4-IoeRPxazwn"></div>

                    <input type="hidden" value="ok" name="form-send">

                    <center><br><button type="submit" class=" centrer btn btn-primary"><?php if($langue=="fr"){echo "Poster";}elseif($langue=="en"){echo"Post";} ?></button></center>

                    </form>

                </div>

                <div class="modal-footer">

                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php if($langue=="fr"){echo "Fermer";}elseif($langue=="en"){echo"Close";} ?></button>

                </div>

            </div>

        </div>

    </div>

    <?php

    if(isset($_POST["form-send"])){

        $googleResponse = false;

        // Ma clé privée

        $secret = "6LcSRXEUAAAAAL1y9QFv4bqETSJrkOuOy22aFRZ2";

        // Paramètre renvoyé par le recaptcha

        $response = $_POST['g-recaptcha-response'];

        // On récupère l'IP de l'utilisateur

        $remoteip = $_SERVER['REMOTE_ADDR'];

        $api_url = "https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$response."&remoteip=".$remoteip;

        $decode = json_decode(file_get_contents($api_url), true);

        if ($decode['success'] == true) {

            $googleResponse = true;

        }else {

            $googleResponse = false;

        }

            $valider_form = 0;

            $message = "";



            // si les infos entrer dans le formulaire sont correctes

            if ($googleResponse == true){

                $valider_form++;

            } else {
                if($langue=="fr"){$message.="Le captcha n'est pas correctement rempli.<br>";}elseif($langue=="en"){$message.="The captcha is not correctly filled.<br>";}
                $valider_form = 0;

            }

            // si les champs sont envoyés

            if(isset($_POST["nom_prenom_com"]) && isset($_POST["commentaire"])){

                $valider_form++;

            } else {
                if($langue=="fr"){$message.="Tous les champs ne sont pas remplis.<br>";}elseif($langue=="en"){$message.="Not all fields are filled.<br>";}

                $valider_form = 0;

            }

            // si les champs ne sont pas vides

            if(!empty($_POST["nom_prenom_com"]) && !empty($_POST["commentaire"])){

                $valider_form++;

            } else {
                if($langue=="fr"){$message.="Tous les champs ne sont pas remplis.<br>";}elseif($langue=="en"){$message.="Not all fields are filled.<br>";}

                $valider_form = 0;

            }

            // on verifie si le nom prenom a la bonne taille

            if(strlen($_POST["commentaire"]) > 5 && strlen($_POST["commentaire"]) < 300){

                $valider_form++;

            } else {
                if($langue=="fr"){$message.="Le commentaire est soit trop court soit trop long.<br>";}elseif($langue=="en"){$message.="The comment is either too short or too long.<br>";}
                $valider_form = 0;

            }

            // on verifie si le texte a la bonne taille

            if(strlen($_POST["nom_prenom_com"]) > 5 && strlen($_POST["nom_prenom_com"]) < 50){

                $valider_form++;

            } else {
                if($langue=="fr"){$message.="Le nom et prenom soit trop court soit trop long.<br>";}elseif($langue=="en"){$message.="The name and surname either too short or too long.<br>";}

                $valider_form = 0;

            }

            if($valider_form == 5){

                $nom_prenom = filter_input(INPUT_POST, 'nom_prenom_com', FILTER_SANITIZE_STRING);

                $commentaire = filter_input(INPUT_POST, 'commentaire', FILTER_SANITIZE_STRING);

                $idpub = filter_input(INPUT_POST, 'idpub', FILTER_SANITIZE_STRING);

                commenter($idpub, $nom_prenom, $commentaire);

                $id_user = recup_id($id_journal);

                notifier($id_user,"Commentaire de ".$nom_prenom ." sur une publication");

                modal("Commentaire publié.");

            } else {

                modal($message);

            }

    }

    ?>

    <!-- Affichage des publication de la personne concerné en fonction de la methode get de la page -->

    <section id="publications">

        <?php 

            // on affiche les publications

            afficher_publications_simple($id_journal);

        ?>

    </section>

    <div id="publicite">

        <?php afficher_publicite() ?>

    </div>

</div>

<script type="text/javascript" src="ressources/js/resize_image.js"></script>

<div id="id_view_image_body"></div>

<div id="id_view_image"></div>

<script type="text/javascript" src="ressources/js/imagezoom.js"></script>

</div>

<!-- FOOTER -->

<footer>

    <?php afficher_footer(); ?>

</footer>

<div id="chargement">

    <img src="ressources/img/chargement.webp" alt="chargement"/>

</div>

<script>

    $(window).on('load', function(){

        $("#chargement img").css("display", "none");

    });

</script>

</body>

</html>
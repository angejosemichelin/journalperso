<?php $langue = langue(); ?>
<div id="starpass_430037"></div><script type="text/javascript" src="https://script.starpass.fr/script.php?idd=430037&amp;verif_en_php=1&amp;datas=<?php echo $_GET["id_user"]; ?>"></script><noscript>Veuillez activer le Javascript de votre navigateur s'il vous pla&icirc;t.<br /><a href="https://www.starpass.fr/">Micro Paiement StarPass</a></noscript>

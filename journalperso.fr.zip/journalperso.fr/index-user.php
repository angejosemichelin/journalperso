<?php  
    // On inclus les fonctions php
    include('fonctions/fonctions.php');

    // Ouvrir session
    ouvrir_session();

    enligne();

    if(!isset($_SESSION["id"])) 
    {
        ?>
        <script>window.location.replace('https://www.journalperso.fr/')</script>
        <?php 
    }
    
    $langue = langue();
?>
<!DOCTYPE html>
<head>
<?php 
    $page = isset($_GET["page"]) ? $_GET["page"] : null;
    $titre_page = titre_page($page);
    $description_page = description_page($page);
    afficher_head($titre_page, $description_page); 
    ?>
</head>
<body>
    <div id="wrapper">
        <!-- HEADER -->
        <header class="positionrelative">
            <div class="langues">
                <a id="fr" href="#"><img src="ressources/img/francais.webp" alt="Passer en langue française sur le site internet journalperso.fr" /></a>
                <a id="en" href="#"><img src="ressources/img/anglais.webp" alt="Passer en langue anglaise sur le site internet journalperso.fr" /></a>
            </div>
            <div id="div_logo">
                    <div style="position:relative">
                    <a href="https://www.journalperso.fr"><img class="logo" src="ressources/img/logo.webp" alt="Logo of the site internet Journalperso.fr - Website of independent journalism and web editors!" /></a>
                    <img style="position:absolute;right:60px;top:15px" src="ressources/img/etoile.webp" alt="Etoiles scitillante"/>
                    </div>
        </div>
        <div id="conteneur_pub">
            <div id="pub">
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- annonce principale -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:90px"
     data-ad-client="ca-pub-1499321886222382"
     data-ad-slot="9836787028"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
            </div>
        </div>
        </header>
        <?php
            if(compte_valider($_SESSION['id']) != 1){
                    ?>
                    <center>
                        <div class="alert alert-warning fontsize09 marginpadding0" role="alert">
                        <?php 
                        if($langue=="fr"){echo "Un mail vous a été envoyé. Veuillez cliquer sur le lien pour valider votre compte. Verfifer vos spams.<a href='index-user.php?page=renvoi_mail_validation_compte' alt='Renvoi du mail de validation du compte'>Renvoyer le mail</a>";}elseif($langue=="en"){echo"An email has been sent to you. Please click on the link to validate your account. Verfifer your spams.<a href='index-user.php?page=renvoi_mail_validation_compte' alt='Return the account validation email'>Resend the mail</a>";} 
                        ?>
                        </div>
                    </center>
                    <?php
            }
            
        ?>
        <!-- NAVBAR -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="index.php?page=accueil"><img src="ressources/img/accueil.webp" alt="Accueil menu"/></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index-user.php?page=accueil-membre"><?php if($langue=="fr"){echo "Accueil";}elseif($langue=="en"){echo"Home";} ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index-user.php?page=creerunjournal"><?php if($langue=="fr"){echo "Créer un journal";}elseif($langue=="en"){echo"Create a journal";} ?></a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php if($langue=="fr"){echo "Vos journaux";}elseif($langue=="en"){echo"Your journals";} ?>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <?php
                        afficher_journaux_creer_menu($_SESSION['id']);
                        ?>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php if($langue=="fr"){echo "Compte";}elseif($langue=="en"){echo"Account";} ?>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="index-user.php?page=moncompte"><?php if($langue=="fr"){echo "Mes infos";}elseif($langue=="en"){echo"My info";} ?></a>
                        <a class="dropdown-item" href="index-user.php?page=statistiques"><?php if($langue=="fr"){echo "Statistiques";}elseif($langue=="en"){echo"Statistics";} ?></a>
                        <a class="dropdown-item" href="index-user.php?page=demande-paiement"><?php if($langue=="fr"){echo "Demande de paiement";}elseif($langue=="en"){echo"Payment";} ?></a>
                        <a class="dropdown-item" href="index-user.php?page=notifications"><?php if($langue=="fr"){echo "Notifications";}elseif($langue=="en"){echo"Notifications";} ?></a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index-user.php?page=parrainnage"><?php if($langue=="fr"){echo "Parrainnage";}elseif($langue=="en"){echo"Sponsorship";} ?></a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php if($langue=="fr"){echo "Jeux";}elseif($langue=="en"){echo"Games";} ?>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="index-user.php?page=jeux"><?php if($langue=="fr"){echo "Ticket gagnant";}elseif($langue=="en"){echo"Winning ticket";} ?></a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="deconnexion.php"><?php if($langue=="fr"){echo "Deconnexion";}elseif($langue=="en"){echo"Log out";} ?></a>
                </li>
                </ul>
            </div>
        </nav>
        <!-- CONTENU -->
        <section id="contenu" class="positionrelative paddingbottom60">
            <?php
                // On gère les pages
                gerer_les_pages(true, $page);
            ?>
            <div id="publicite">
                <?php afficher_publicite() ?>
            </div>
        </section>
    </div>
    <!-- FOOTER -->
    <footer>
        <?php afficher_footer(); ?>
    </footer>
    <div id="chargement">
        <img src="ressources/img/chargement.webp" alt="chargement"/>
    </div>
    <script>
        $(window).on('load', function(){
            $("#chargement img").css("display", "none");
        });
    </script>
</body>
</html>
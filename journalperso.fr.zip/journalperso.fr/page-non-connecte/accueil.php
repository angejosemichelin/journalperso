<?php $langue = langue(); ?>
<script>
    
    $( function() {
        $( "#dialog" ).dialog({
                        width: 500,
                        dialogClass: "no-close",
                        buttons: [
                            {
                            text: "Fermer",
                            click: function() {
                                $( this ).dialog( "close" );
                            }
                            }
                        ]
        });
        if (window.matchMedia("(max-width: 600px)").matches) {
            $( "#dialog" ).dialog({width: 300});
        } else {
            $( "#dialog" ).dialog({width: 500});
        }
    });


</script>
<div id="dialog" title="<?php if($langue=="fr"){echo "Bienvenue sur notre innovation !";}elseif($langue=="en"){echo"Welcome to our innovation!";} ?>">

        <p><?php if($langue=="fr"){echo "Incrivez vous notre site qui est juste surpuissant! Nous avons besoin de vous! Laissez vous guidez vous avez tout à gagner, le site est entierment automatisé et comme je l'ai dis est surpuissant. Aidez nous à demarrer :)";}elseif($langue=="en"){echo"Subscribe to our site which is just overpowering! We need you! Let you guide you have everything to gain, the site is fully automated and as I said is overpowering. Help us get started :)";} ?></p>
        <br><ul style="font-weight:bold;">
            <li><?php if($langue=="fr"){echo "Vendez vos fichiers important!";}elseif($langue=="en"){echo"Sell ​​your important files!";} ?></li>
            <li><?php if($langue=="fr"){echo "Vendez vos contenus importants!";}elseif($langue=="en"){echo"Sell ​​your important content!";} ?></li>
        </ul><br>
        <p><?php if($langue=="fr"){echo "Un petit J'aime Facebook ?";}elseif($langue=="en"){echo"A little Facebook Like?";} ?></p>
        <center><div class="fb-like" data-href="https://www.facebook.com/Journalpersofr-113698867066140/" data-width="" data-layout="box_count" data-action="like" data-size="small" data-share="true"></div></center><br>
        <p><?php if($langue=="fr"){echo "Participez à l'amelioration du site:";}elseif($langue=="en"){echo"Participate in the improvement of the site:";} ?> <a style="border:none;outline:none;text-decoration:underline;color:blue" href="https://paypal.me/pools/c/8sBrsw1mUa" alt="Participation à l'amelioration du site"><?php if($langue=="fr"){echo "Cliquez ici!";}elseif($langue=="en"){echo"Click here!";} ?></a></p>
    </div>

<?php

    if($langue=="fr"){

?>

        <img id="imageintro2" src="ressources/img/banniereintro2.webp" alt="Explications du fonctionnement de journalperso.fr" />

        <img id="imageintro" src="ressources/img/banniereintro.webp" alt="Explications du fonctionnement de journalperso.fr" />

<?php 

    }elseif($langue=="en"){

?>

        <img id="imageintro2" src="ressources/img/banniereintro2_en.webp" alt="Explications du fonctionnement de journalperso.fr" />

        <img id="imageintro" src="ressources/img/banniereintro_en.webp" alt="Explications du fonctionnement de journalperso.fr" />

        <?php

    }

?>

<section class="verticalaligntop">

    <section id="inscription_accueil">

        <center class="margintop5"><div class="hvr-grow fb-login-button" scope="public_profile,email" onlogin="checkLoginState();" data-width="" data-size="large" data-button-type="continue_with" data-auto-logout-link="false" data-use-continue-as="false"></div></center>

            <h1 class="h1"><?php if($langue=="fr"){echo "Devenez rédacteur web - Inscription rapide !";}elseif($langue=="en"){echo"Become web redacteur - Quick registration!";} ?></h1>

            <form action="index.php?page=validation-inscription" method="post" id="inscriptionRapide">

                    <?php

                        if($langue=="fr"){

                            input("email", "Adresse e-mail:", "email_inscription", "email", "Entrez votre adresse e-mail", true, "", "");

                            input("text", "Nom et prénom:", "nom_prenom", "nom_prenom", "Entrez votre nom et prénom", true, "", "");

                            ?>

                            <div class="form-group">

                                <label for="password">Mot de passe</label>

                                <div style="position:relative">

                                <input type="password" class="form-control" id="password" required minlength='4' maxlength='50' name="mdp" placeholder="Mot de passe">

                                <span class="show-password">afficher</span>

                                </div>

                            </div>

                            <?php

                        }elseif($langue=="en"){

                            input("email", "E-mail adress:", "email_inscription", "email", "Enter your e-mail adress", true, "", "");

                            input("text", "Last name and first name", "nom_prenom", "nom_prenom", "Enter your name and surname in full", true, "", "");

                            ?>

                            <div class="form-group">

                                <label for="password">Mot de passe</label>

                                <div style="position:relative">

                                <input type="password" class="form-control" id="password" required minlength='4' maxlength='50' name="mdp" placeholder="Mot de passe">

                                <span class="show-password">display</span>

                                </div>

                            </div>

                            <?php

                        }

                        if(isset($_GET["parrain"])){

                            $parrain = $_GET["parrain"];

                        }elseif(isset($_COOKIE["parrain"])){

                            $parrain = $_COOKIE["parrain"];

                        }else{

                            $parrain = null;

                        }

                    ?>

                    <input type="hidden" name="parrain" value="<?php echo $parrain; ?>">

                    <div class="g-recaptcha" data-sitekey="6LcSRXEUAAAAAAMk7u5oZGHx1QtV4-IoeRPxazwn"></div><br>

                    <center><button type="submit" class="centrer btn btn-primary"><?php if($langue=="fr"){echo "Devenez rédacteur web!";}elseif($langue=="en"){echo"Become web editor!";} ?></button></center>

            </form>

    </section>

    <aside id="image_accueil">

        <img class="texteplante" src="ressources/img/Photo-Journalperso-texteetplante.webp" alt="Journalperso.fr - Logo journalisme et web redacteur révéler vos talents idées notes centre d'interet"/>

        <p class="nbr_journaux"><?php echo nombre_utlisateur(); ?><?php if($langue=="fr"){echo " inscriptions";}elseif($langue=="en"){echo" registering";} ?></p>

        <p class="nbr_journaux"><?php echo nombre_journaux(); ?><?php if($langue=="fr"){echo " journaux personnels";}elseif($langue=="en"){echo" personal journals";} ?></p>

        <p class="nbr_journaux fontsize09"><?php echo enligne(); ?><?php if($langue=="fr"){echo " visiteurs en ligne";}elseif($langue=="en"){echo" visitors online";} ?></p>

        <p class="nbr_journaux fontsize09"><?php echo visiteursjournee(); ?><?php if($langue=="fr"){echo " visiteurs aujourd'hui";}elseif($langue=="en"){echo" visitors today";} ?></p>

        <p class="nbr_journaux fontsize09"><?php echo visiteurstotal(); ?><?php if($langue=="fr"){echo " visiteurs depuis de debut";}elseif($langue=="en"){echo" visitors total since beginning";} ?></p>

        <div class="benefices alert alert-secondary" role="alert">

        <?php if($langue=="fr"){echo "Bénéfices des membres: ";}elseif($langue=="en"){echo"Members benefits: ";} ?> <strong><?php echo gain_membre(); ?>€</strong>

        </div>

    </aside>

</section>

<!-- Bloc Introduction -->

<section id="introduction">

    <?php

if($langue=="fr"){

        ?>

        <h1 class="h1">Ecrivez des journaux personnels en ligne, devenez redacteur web !</h1>

        <?php

    }elseif($langue=="en"){

        ?>

        <h1 class="h1">Write personnal journal online, become web editor!</h1> 

        <?php

    }

    ?>

    <script>

        function ajoutervue(){

            $.ajax({

                url: 'page-non-connecte/envoi_vue.php'

            });

        }

    </script>

    <section id="div_introduction">

        <aside id="video_presentation" class="verticalaligntop">

            <video onplaying="ajoutervue()" class="video_intro" width="300" height="300" poster="ressources/img/video.webp" preload="auto" controls>

                <source src="ressources\videos\video_presentation.webm">

                <source src="ressources\videos\video_presentation.mp4">

                Vidéos de présentation de journalperso.fr par le créateur Ange-José Michelin

            </video>

            <p id="vue_video"><?php if($langue=="fr"){echo "Nombre de vues de la vidéo:";}elseif($langue=="en"){echo"Number of views of the video:";} ?><?php echo affichervuephp() ?></p>

        </aside>

        <?php afficher_introduction(); ?>

        <p id="plus"><?php if($langue=="fr"){echo "+ des jeux et autres !";}elseif($langue=="en"){echo"+ games and more!";} ?></p>

    </section>

</section>

<div class="slideshow">

    <ul>

        <?php afficher_meilleurs_journaux_card(); ?>

    </ul>

</div>  

<script type="text/javascript">

        $(function(){

            setInterval(function(){

                $(".slideshow ul").animate({marginLeft:-350},800,function(){

                    $(this).css({marginLeft:0}).find("li:last").after($(this).find("li:first"));

                })

            }, 2500);

        });

</script>
<?php
$langue = langue();
?>
<h1 class="h1"><?php if($langue=="fr"){echo "Journal personnel en ligne - Journaux personnels par thèmes";}elseif($langue=="en"){echo"Personal diary online - Personals journals by themes";} ?></h1>
<div class="responsive-50 list-group">
    <a href="index.php?page=journaux-par-themes&theme=1" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Gagner de l'argent";}elseif($langue=="en"){echo "Earn money";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(1);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=2" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Vie privée";}elseif($langue=="en"){echo "Private life";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(2);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=3" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Santé";}elseif($langue=="en"){echo "Health";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(3);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=4" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Sport";}elseif($langue=="en"){echo "Sport";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(4);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=5" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Medecine";}elseif($langue=="en"){echo "Medicine";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(5);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=6" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Actualité";}elseif($langue=="en"){echo "News";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(6);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=7" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Vie quotidienne";}elseif($langue=="en"){echo "Everyday life";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(7);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=8" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Infos utiles";}elseif($langue=="en"){echo "Useful informations";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(8);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=9" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Littérature";}elseif($langue=="en"){echo "Literature";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(9);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=10" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Ecriture créative";}elseif($langue=="en"){echo "Creative writing";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(10);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=11" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Poèmes";}elseif($langue=="en"){echo "Poems";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(11);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=12" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Photographie";}elseif($langue=="en"){echo "Photography";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(12);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=13" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Musique";}elseif($langue=="en"){echo "Music";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(13);?></span>
    </a>
</div>
<div class="responsive-50 list-group">
    <a href="index.php?page=journaux-par-themes&theme=14" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Films";}elseif($langue=="en"){echo "Movies";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(14);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=15" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Internet";}elseif($langue=="en"){echo "Internet";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(15);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=16" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Histoire";}elseif($langue=="en"){echo "History";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(16);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=17" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Scolaire";}elseif($langue=="en"){echo "School";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(17);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=18" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Informatique";}elseif($langue=="en"){echo "IT";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(18);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=19" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Sciences";}elseif($langue=="en"){echo "Science";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(19);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=20" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Economie";}elseif($langue=="en"){echo "Economy";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(20);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=21" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Réseaux sociaux";}elseif($langue=="en"){echo "Social networks";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(21);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=22" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Profession par métiers";}elseif($langue=="en"){echo "Occupation by profession";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(22);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=23" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Divertissement";}elseif($langue=="en"){echo "Entertainment";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(23);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=24" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Jeux";}elseif($langue=="en"){echo "Games";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(24);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=25" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Hot";}elseif($langue=="en"){echo "Hot";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(25);?></span>
    </a>
    <a href="index.php?page=journaux-par-themes&theme=26" class="list-padding list-group-item list-group-item-action d-flex justify-content-between align-items-center">
        <?php if($langue=="fr"){echo "Autres";}elseif($langue=="en"){echo "Others";}?>
        <span class="badge badge-primary badge-pill"><?php echo return_nbr_theme(26);?></span>
    </a>
</div>
<div id="meilleurs_journaux">
   <h1 class="h1"><img class="podium" src="ressources/img/podium-page-accueil.webp" alt="Podium"/><?php if($langue=="fr"){echo "Devenez web rédacteur - Journaux personnels les plus visités";}elseif($langue=="en"){echo"Become web editor - Most visited personal journals";} ?></h1>
    <div class="slideshow">
        <ul>
            <?php afficher_meilleurs_journaux_card(); ?>
        </ul>
    </div>       
    <script type="text/javascript">
        $(function(){
            setInterval(function(){
                $(".slideshow ul").animate({marginLeft:-350},800,function(){
                    $(this).css({marginLeft:0}).find("li:last").after($(this).find("li:first"));
                })
            }, 2500);
        });
    </script>
    <?php afficher_meilleurs_journaux(40, "index.php?page=touslesjournaux"); ?>
</div>
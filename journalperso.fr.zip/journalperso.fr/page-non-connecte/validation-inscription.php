<?php
$langue = langue();
?>
<h1 class="h1"><?php if($langue=="fr"){echo "Gagnez de l'argent en ligne - Validation inscription sur Journalperso.fr, le site de webrédaction numéro 1!";}elseif($langue=="en"){echo"Make money online - Registration validation on Journalperso.fr, the webrédaction site number 1!";} ?></h1>
<div class="contenu-centre">
<?php
$googleResponse = false;
// Ma clé privée
$secret = "6LcSRXEUAAAAAL1y9QFv4bqETSJrkOuOy22aFRZ2";
// Paramètre renvoyé par le recaptcha
$response = $_POST['g-recaptcha-response'];
// On récupère l'IP de l'utilisateur
$remoteip = $_SERVER['REMOTE_ADDR'];
$api_url = "https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$response."&remoteip=".$remoteip;
$decode = json_decode(file_get_contents($api_url), true);
if ($decode['success'] == true) {
    $googleResponse = true;
}else {
    $googleResponse = false;
}

$valider_form = 0;
$message = "";
// si les infos entrer dans le formulaire sont correctes
if (($googleResponse == true)){
    $valider_form++;
} else {
    $message.="Le captcha est invalide.<br>";
    $valider_form = 0;
}

// on verfifie si tout les champs sont remplis
if(isset($_POST['mdp']) && isset($_POST['email']) && isset($_POST['nom_prenom'])){
    $valider_form++;
} else {
    $message.="Tous les champs ne sont pas remplis.<br>";
    $valider_form = 0;
}

// on verifie si le mot de passe a la bonne taille
if(strlen($_POST['mdp']) > 5 && strlen($_POST['mdp']) < 50){
    $valider_form++;
} else {
    $message.="Le mot de passe est soit trop court soit trop long.<br>";
    $valider_form = 0;
}

// ON verifie si le nom prenom a la bonne taille
if(strlen($_POST['nom_prenom']) > 5 && strlen($_POST['nom_prenom']) < 100){
    $valider_form++;
} else {
    $message.="Le nom et le prénom sont soit trop longs soit trop court.<br>";
    $valider_form = 0;
}

// On verifie si l'email est valide
if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
    $valider_form++;
} else {
    $message.="L'email n'est pas valide.<br>";
    $valider_form = 0;
}

// on verifier si l'utilisateur est deja inscrit
$nombre_user = utilisateur_existe($_POST['email']);

if($nombre_user > 0){
    $message.="Cet utilisateur est déja inscrit.<br>";
    $valider_form = 0;
} else {
    $valider_form++;
}

if($valider_form == 6){
// on recupere les infos du formulaire
$mdp = filter_input(INPUT_POST, 'mdp', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
$nom_prenom = filter_input(INPUT_POST, 'nom_prenom', FILTER_SANITIZE_STRING);
$parrain = isset($_POST["parrain"]) ? $_POST["parrain"] : 0;
$hashed_password = crypt($mdp, '');

//sinon inscirption
inscription($email, $hashed_password, $nom_prenom, $mdp, $parrain);
?>
    <center><p><?php if($langue=="fr"){echo "Vous etes inscrit. <strong>Un mail vous à été envoyé.</strong> Veuillez cliquer sur le lien dans cet email pour activé votre compte. Verifiez dans vos spams. Vous pouvez vous connecter en attendant en cliquant sur Connexion.";}elseif($langue=="en"){echo"You are registered. <strong>An email has been sent to you.</strong> Please click on the link in this email to activate your account. Check in your spam. You can log in while waiting by clicking Login.";} ?><br><a href="/"><?php if($langue=="fr"){echo "<< Retour <<";}elseif($langue=="en"){echo"<< Back <<";} ?></a></p></center>
<?php   
} 
echo "<center>".$message."</center>";
?>
</div>
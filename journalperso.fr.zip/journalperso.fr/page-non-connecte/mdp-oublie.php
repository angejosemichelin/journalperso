<?php 
$langue = langue();
if(isset($_POST["email"])){
    $email_new = $_POST["email"];
?>
<div class="changer_mdp">
    <h1 class="h1"><?php if($langue=="fr"){echo "Gagnez de l'argent en ligne - Changer de mot de passe";}elseif($langue=="en"){echo"Make money online - Change password";} ?></h1>
    <div class="contenu-centre">
    <form action="index.php?page=motdepasse-oublie" method="post">
        <?php
        if($langue=="fr"){ 
            ?>
                <div class="form-group">
                    <label for="mdp_oublie1">Nouveau mot de passe:</label>
                    <div style="position:relative">
                    <input type="password" class="form-control" id="mdp_oublie1" required minlength='4' maxlength='50' name="password" placeholder="Mot de passe">
                    <span class="show-password">afficher</span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="mdp_oublie2">Répéter nouveau mot de passe:</label>
                    <div style="position:relative">
                    <input type="password" class="form-control" id="mdp_oublie2" required minlength='4' maxlength='50' name="repeat_password" placeholder="Mot de passe">
                    <span class="show-password">afficher</span>
                    </div>
                </div>
            <?php 
            }elseif($langue=="en"){
                ?>
                <div class="form-group">
                    <label for="mdp_oublie1">New password:</label>
                    <div style="position:relative">
                    <input type="password" class="form-control" id="mdp_oublie1" required minlength='4' maxlength='50' name="password" placeholder="New password">
                    <span class="show-password">display</span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="mdp_oublie2">Repeat new password:</label>
                    <div style="position:relative">
                    <input type="password" class="form-control" id="mdp_oublie2" required minlength='4' maxlength='50' name="repeat_password" placeholder="Repeat new password">
                    <span class="show-password">display</span>
                    </div>
                </div>
            <?php 
            }
        ?>
        <input type="hidden" name="email_new" value="<?php echo $email_new; ?>">
        <center><button type="submit" class=" centrer btn btn-primary"><?php if($langue=="fr"){echo "Valider";}elseif($langue=="en"){echo"Validate";} ?></button></center>
    </form>
    </div>
</div>
<?php
} elseif(isset($_POST["password"])){
    $mdp = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    $mdp_repeat = filter_input(INPUT_POST, 'repeat_password', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email_new', FILTER_SANITIZE_STRING);
    
    if($mdp_repeat == $mdp){
            if(utilisateur_existe($email) > 0){
                $hashed_password2 = crypt($mdp, '');
                $valeurs = [
                    "mdp" => $hashed_password2,
                    "email" => $email
                ];
                update_bdd("UPDATE users SET mdp = :mdp WHERE email = :email", $valeurs);
                ?>
                    <p style="text-align:center;"><?php if($langue=="fr"){echo "Mot de passe changé.";}elseif($langue=="en"){echo"Password change.";} ?><br/><a href="/"><?php if($langue=="fr"){echo "<< Retour <<";}elseif($langue=="en"){echo"<< Back <<";} ?></a></p>
                    <br/><br/>
                <?php
            } else {
                ?>
                    <p style="text-align:center;"><?php if($langue=="fr"){echo "Cet utilisateur n'existe pas.";}elseif($langue=="en"){echo"This user does not exist.";} ?></p>
                <?php
            }
    } else {
        ?>
        <p class="aligncenter"><?php if($langue=="fr"){echo "Les mots de passe ne sont pas identiques.";}elseif($langue=="en"){echo"Passwords are not the same.";} ?></p>
    <?php
        }
} else {
?>
<div class="changer_mdp">
    <h1 class="h1"><?php if($langue=="fr"){echo "Devenez web rédacteur - Changer de mot de passe";}elseif($langue=="en"){echo"Become web editor - Change password";} ?></h1>
    <div class="contenu-centre">
    <form action="index.php?page=motdepasse-oublie" method="post">
        <?php
            if($langue=="fr"){
                input("email", "Adresse e-mail:", "email_connexion", "email", "Entrez votre adresse e-mail", true, "", "minlength='4' maxlength='50'");
            }elseif($langue=="en"){
                input("email", "E-mail adress:", "email_connexion", "email", "Enter your e-mail adress", true, "", "minlength='4' maxlength='50'");
            }
        ?>
        <center><button type="submit" class=" centrer btn btn-primary"><?php if($langue=="fr"){echo "Continuer";}elseif($langue=="en"){echo"Continue";} ?></button></center>
    </form>
    </div>
</div>
<?php
}
?>



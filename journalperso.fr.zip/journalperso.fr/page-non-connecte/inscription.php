<?php $langue = langue(); ?>
<!-- Bloc inscription -->
<div id="inscription">
    <h1 class="h1"><?php if($langue=="fr"){echo "Journal personnel numérique - Inscription sur notre site de journalisme Journalperso.fr";}elseif($langue=="en"){echo"Digital personal diary - Registration on our journalism site Journalperso.fr";} ?></h1>
    <div class="contenu-centre">
        <form action="index.php?page=validation-inscription" method="post">
            <?php
                if($langue=="fr"){
                    input("email", "Adresse e-mail:", "email_inscription", "email", "Entrez votre adresse e-mail", true, "", "minlength='4' maxlength='50'");
                    input("text", "Nom et prenom:", "nom_prenom", "nom_prenom", "Entrez votre nom et prénom", true, "", "minlength='4' maxlength='50'");
                    ?>
                    <div class="form-group">
                        <label for="password">Mot de passe</label>
                        <div style="position:relative">
                        <input type="password" class="form-control" id="password" required minlength='4' maxlength='50' name="mdp" placeholder="Mot de passe">
                        <span class="show-password">afficher</span>
                        </div>
                    </div>
                    <?php
                    }elseif($langue=="en"){
                    input("email", "E-mail adress:", "email_inscription", "email", "Enter your e-mail adress", true, "", "minlength='4' maxlength='50'");
                    input("text", "Last name and first name", "nom_prenom", "nom_prenom", "Enter your name and surname in full", true, "", "minlength='4' maxlength='50'");
                    ?>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <div style="position:relative">
                                <input type="password" class="form-control" id="password" required minlength='4' maxlength='50' name="mdp" placeholder="Mot de passe">
                                <span class="show-password">display</span>
                                </div>
                            </div>
                    <?php                
                    }
                if(isset($_GET["parrain"])){
                    $parrain = $_GET["parrain"];
                }elseif(isset($_COOKIE["parrain"])){
                    $parrain = $_COOKIE["parrain"];
                }else{
                    $parrain = null;
                }
            ?>
            <input type="hidden" name="parrain" value="<?php echo $parrain; ?>">
            <div class="g-recaptcha" data-sitekey="6LcSRXEUAAAAAAMk7u5oZGHx1QtV4-IoeRPxazwn"></div><br>
            <center><button type="submit" class=" centrer btn btn-primary"><?php if($langue=="fr"){echo "Devenez rédacteur web!";}elseif($langue=="en"){echo"<strong>Become a web editor!</strong>";} ?></button></center>
        </form>
    </div>
</div>
<?php
$langue = langue();
?>
<h1 class="h1"><?php if($langue=="fr"){echo "Site de journalisme indépendant - Journaux personnels par thèmes";}elseif($langue=="en"){echo"Independent journalism site - Personal journals by themes";} ?></h1>
<?php
return_journaux_par_theme($_GET["theme"]);
?>
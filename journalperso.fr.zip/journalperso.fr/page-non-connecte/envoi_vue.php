<?php
    // On inclus les fonctions php
    include('../fonctions/fonctions.php');

    //on ajoute une vue a la video
    ajoutervuephp();
?>
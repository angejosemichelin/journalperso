<?php
$langue = langue();
?>
<h1 class="h1"><?php if($langue=="fr"){echo "Journal personnel numérique - Validation compte sur le site de redaction web Journalperso.fr";}elseif($langue=="en"){echo"Digital personal diary - Validation account on the editorial web site Journalperso.fr";} ?></h1>
<div class="contenu-centre">
<?php
if(isset($_GET['valide'])){
    $chiffre = $_GET['valide'];
    $chiffre_compte = chiffre_compte_valide($_GET['email']);
    if($chiffre == $chiffre_compte){
        ?>
        <!-- Pubdirecte L --><img src="https://www.pubdirecte.com/script/lead.php?s=25800&u=92488&mail=<?php echo $_GET['email']; ?>&id=&tel=&nom=&prenom=" height="1" width="1" border="0"><!-- Pubdirecte L -->
        <?php      
        valide_compte($_GET['email']);
        if($langue=="fr"){echo "Votre compte est validé.";}elseif($langue=="en"){echo"Your account is valided.";}
    }
} else {
    if($langue=="fr"){echo "Erreur.";}elseif($langue=="en"){echo"Error.";}
}
?>
<br>
<center><a href="https://journalperso.fr/index.php?page=connexion" alt="Créez votre premier journal"><img class="hvr-grow boutonaide" src="ressources/img/bouton-aide.webp" alt="Créez votre premier journal" /></a></center>
</div>
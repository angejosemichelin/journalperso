<?php $langue = langue(); ?>
<h1 class="h1"><?php if($langue=="fr"){echo "Journal intime en ligne - Ecrivez un avis sur notre site";}elseif($langue=="en"){echo"Online diary - Write a review on our site";} ?></h1>
<!-- Modal -->
<div class="modal fade" id="ecrireavis" tabindex="-1" role="dialog" aria-labelledby="ecrireavislab" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ecrireavislab"><?php if($langue=="fr"){echo "Ecrire un avis ou un temoignage";}elseif($langue=="en"){echo"Write a Opinions and testimonials";} ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post">
                        <?php
                            if($langue=="fr"){
                                input("text", "Nom et prénom:", "nom_prenom_avis", "nom_prenom_avis", "Nom et prénom", true, "", "minlength='4' maxlength='50'");
                            }elseif($langue=="en"){
                                input("text", "Last name and first name:", "nom_prenom_avis", "nom_prenom_avis", "Last name and first name", true, "", "minlength='4' maxlength='50'");
                            }
                        ?>
                        <label><?php if($langue=="fr"){echo "Votre avis sur le site:";}elseif($langue=="en"){echo"Your think about the website:";} ?></label>
                        <textarea class="form-control" minlength='20' maxlength='500' rows="4" id="avis" name="avis" required aria-label="Ecrire un avis ou un temoignage..."></textarea>
                        <br><div class="g-recaptcha" data-sitekey="6LcSRXEUAAAAAAMk7u5oZGHx1QtV4-IoeRPxazwn"></div>
                        <input type="hidden" value="ok" name="form-send">
                        <center><br><button type="submit" class="centrer btn btn-primary"><?php if($langue=="fr"){echo "Poster";}elseif($langue=="en"){echo"Post";} ?></button></center>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php if($langue=="fr"){echo "Fermer";}elseif($langue=="en"){echo"Close";} ?></button>
            </div>
        </div>
    </div>
</div>
<center><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ecrireavis"><?php if($langue=="fr"){echo "Ecrire un avis ou un temoignage";}elseif($langue=="en"){echo"Write a Opinions and testimonials";} ?></button></center>
<?php
    if(isset($_POST["form-send"])){
            $googleResponse = false;
            // Ma clé privée
            $secret = "6LcSRXEUAAAAAL1y9QFv4bqETSJrkOuOy22aFRZ2";
            // Paramètre renvoyé par le recaptcha
            $response = $_POST['g-recaptcha-response'];
            // On récupère l'IP de l'utilisateur
            $remoteip = $_SERVER['REMOTE_ADDR'];
            $api_url = "https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$response."&remoteip=".$remoteip;
            $decode = json_decode(file_get_contents($api_url), true);
            if ($decode['success'] == true) {
                $googleResponse = true;
            }else {
                $googleResponse = false;
            }

            $valider_form = 0;
            $message = "";

            // si les infos entrer dans le formulaire sont correctes
            if ($googleResponse == true){
                $valider_form++;
            } else {
                $message.="Le captcha n'est pas correctement rempli.<br>";
                $valider_form = 0;
            }
            // si les champs sont envoyés
            if(isset($_POST["nom_prenom_avis"]) && isset($_POST["avis"])){
                $valider_form++;
            } else {
                $message.="Tous les champs ne sont pas remplis.<br>";
                $valider_form = 0;
            }
            // si les champs ne sont pas vides
            if(!empty($_POST["nom_prenom_avis"]) && !empty($_POST["avis"])){
                $valider_form++;
            } else {
                $message.="Tous les champs ne sont pas remplis.<br>";
                $valider_form = 0;
            }
            // on verifie si le nom prenom a la bonne taille
            if(strlen($_POST["avis"]) > 5 && strlen($_POST["avis"]) < 200){
                $valider_form++;
            } else {
                $message.="L avis est soit trop court soit trop long.<br>";
                $valider_form = 0;
            }
            // on verifie si le texte a la bonne taille
            if(strlen($_POST["nom_prenom_avis"]) > 5 && strlen($_POST["nom_prenom_avis"]) < 50){
                $valider_form++;
            } else {
                $message.="Le nom et prenom soit trop court soit trop long.<br>";
                $valider_form = 0;
            }
            if($valider_form == 5){
                $nom_prenom = filter_input(INPUT_POST, 'nom_prenom_avis', FILTER_SANITIZE_STRING);
                $avis = filter_input(INPUT_POST, 'avis', FILTER_SANITIZE_STRING);
                laisseravis($nom_prenom, $avis);
                modal("Avis publié !");
            } else {
                modal($message);
            }
                
        }
?>
<?php afficher_avis(5, "index.php?page=avis");?>

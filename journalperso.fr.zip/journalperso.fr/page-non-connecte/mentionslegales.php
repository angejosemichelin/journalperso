<?php $langue = langue(); ?>
<?php
    if($langue=="fr"){
        ?>
        <h1 class="h1">Devenez journaliste en ligne - Mentions légales du site de journalisme Journalperso.fr</h1>
        <div class="contenu-centre">
        Conformément aux dispositions de la loi n° 2004-575 du 21 juin 2004 pour la confiance en l'économie numérique, il est précisé aux utilisateurs du site Journalperso.fr l'identité des différents intervenants dans le cadre de sa réalisation et de son suivi.
        <b>Edition du site</b>
        Le présent site, accessible à l’URL www.journalperso.fr  (le « Site »), est édité par :
        Mrs X, résidant X de nationalité X, né(e) le X.
        <b>Hébergement</b>
        Le Site est hébergé par la société X, situé X, (téléphone : X).
        Directeur de publication 
        Le Directeur de la publication du Site est X.
        <b>Nous contacter</b>
        Par téléphone : X
        Par email : X
        Par courrier : X
        <b>Données personnelles</b>
        Le traitement de vos données à caractère personnel est régi par notre Charte du respect de la vie privée conformément au Règlement Général sur la Protection des Données 2016/679 du 27 avril 2016 (« RGPD »). 
    </div>
        <?php
    }elseif($langue=="en"){
        ?>
        <h1 class="h1">Become an online journalist - Legal mentions of the journalism site Journalperso.fr</h1>
        <div class="contenu-centre">
        In accordance with the provisions of the law n ° 2004-575 of June 21st, 2004 for the confidence in the digital economy, it is clear to the users of the site Journalperso.fr the identity of the various contributors within the framework of its realization and its follow-up .
        <b>Editing the site</b>
        This site, accessible at the URL www.journalperso.fr (the "Site"), is published by:
        Mrs X, residing X X, born on X.
        <b>Accommodation</b>
        The Site is hosted by the company X, located in X, (phone: X).
        Publication director
        The Director of the publication of the Site is X.
        <b>Contact us</b>
        By phone: X
        By email: X
        By mail: X
        <b>Personal data</b>
        The processing of your personal data is governed by our Privacy Policy in accordance with the General Data Protection Regulation 2016/679 of 27 April 2016 ("RGPD").
    </div>
        <?php
    }
?>

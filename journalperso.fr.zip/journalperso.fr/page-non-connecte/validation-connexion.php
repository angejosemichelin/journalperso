<?php
$langue = langue();
?>
<h1 class="h1"><?php if($langue=="fr"){echo "Site de journalisme indépendant - Validation connexion à votre compte Journalperso.fr";}elseif($langue=="en"){echo"Independent journalism site - Validation log in to your Journalperso.fr account";} ?></h1>
<?php
// verification des information, enregistrement dans la session des infos utilisateurs et redirection vers les publications
if(isset($_POST['mdp']) && isset($_POST['email'])){
    $mdp = filter_input(INPUT_POST, 'mdp', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
    connexion_user($email, $mdp);
} else {
    // sinon on detruit la session et on affiche un message d'erreur
    session_destroy();
    ?>
    <p><?php if($langue=="fr"){echo "Erreur connexion.";}elseif($langue=="en"){echo"Connection error.";} ?></p>
    <?php
}
?>
<?php $langue = langue(); ?> 
<!-- Bloc connexion -->
<div id="connexion">
    <h1 class="h1"><?php if($langue=="fr"){echo "Journal personnel en ligne - Connexion à votre espace membre";}elseif($langue=="en"){echo"Personal diary online - Login to your member area";} ?></h1>
    <div class="contenu-centre">
        <form action="index.php?page=validation-connexion" method="post">
            <?php
                if($langue=="fr"){
                    input("email", "Adresse e-mail:", "email_connexion", "email", "Entrez votre adresse e-mail", true, "", "minlength='4' maxlength='50'");
                }elseif($langue=="en"){
                    input("email", "E-mail adress:", "email_connexion", "email", "Enter your e-mail adress", true, "", "minlength='4' maxlength='50'");
                }
                
                if($langue=="fr"){
                 ?>
                <div class="form-group">
                    <label for="mdp">Mot de passe</label>
                    <div style="position:relative">
                    <input type="password" class="form-control" id="mdp" required minlength='4' maxlength='50' name="mdp" placeholder="Mot de passe">
                    <span class="show-password">afficher</span>
                    </div>
                </div>
                  <?php         
                }elseif($langue=="en"){
                    ?>
                    <div class="form-group">
                    <label for="mdp">Password</label>
                    <div style="position:relative">
                    <input type="password" class="form-control" id="mdp" required minlength='4' maxlength='50' name="mdp" placeholder="Password">
                    <span class="show-password">display</span>
                    </div>
                </div>
                <?php
                }
                ?>
            <center><button type="submit" class="centrer btn btn-primary"><?php if($langue=="fr"){echo "Connexion";}elseif($langue=="en"){echo"Log in";} ?></button></center>
        </form>
        <p class="p-mdpoublie"><a id="mdp_oublie" href="index.php?page=motdepasse-oublie"><?php if($langue=="fr"){echo "Mot de passe oublié ?";}elseif($langue=="en"){echo"Forgotten password ?";} ?></a></p>
    </div>
</div>

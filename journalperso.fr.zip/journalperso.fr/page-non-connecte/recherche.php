<?php $langue = langue(); ?>
<h1 class="h1"><?php if($langue=="fr"){echo "Devenez web rédacteur - Recherche sur notre site de web redaction Journalperso.fr";}elseif($langue=="en"){echo"Become web editor - Search on our web site redaction Journalperso.fr";} ?></h1>
<div class="contenu-centre">
<?php 
$recherche = isset($_POST["recherche"]) ? filter_input(INPUT_POST, 'recherche', FILTER_SANITIZE_STRING) : null;
afficher_resultats_recherche($recherche);
?>
</div>
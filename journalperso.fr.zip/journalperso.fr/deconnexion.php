<?php 
    // On inclus les fonctions php
    include('fonctions/fonctions.php');
    //deconnexion
    deconnexion();
?>
<script>
    FB.logout();
</script>